/*
 * FT60x Production Configuration Tool
 * Supports:
 *   - Non-interactive CLI
 *   - Short & long args (--m / --mode etc.)
 *   - FT600 / FT601 auto-detection
 *   - Safe EEPROM flashing with backup + validation
 */

#include "ftd3xx.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define TRUE 1
#define FALSE 0

typedef struct {
    int mode;       // 245 or 600
    int channels;   // 1,2,4
    int clock;      // 66 or 100
    int notify;     // 0/1
} USER_CONFIG;

//////////////////////////////////////////////////////////
// Usage
//////////////////////////////////////////////////////////
void PrintUsage()
{
    printf("\nUsage:\n");
    printf("  ./ConfigTool-dynamic -m 600 -ch 4 -clk 100 -n 1\n\n");

    printf("Options:\n");
    printf("  -m,  --mode       : 245 | 600\n");
    printf("  -ch, --channels   : 1 | 2 | 4\n");
    printf("  -clk,--clock      : 66 | 100\n");
    printf("  -n,  --notify     : 0 | 1\n\n");
}

//////////////////////////////////////////////////////////
// Parse CLI args
//////////////////////////////////////////////////////////
int ParseArgs(int argc, char **argv, USER_CONFIG *cfg)
{
    for (int i = 1; i < argc; i++)
    {
        if (!strcmp(argv[i], "--mode") || !strcmp(argv[i], "--m") || !strcmp(argv[i], "-m"))
        {
            if (++i >= argc) return FALSE;
            cfg->mode = atoi(argv[i]);
        }
        else if (!strcmp(argv[i], "--channels") || !strcmp(argv[i], "--ch") || !strcmp(argv[i], "-ch"))
        {
            if (++i >= argc) return FALSE;
            cfg->channels = atoi(argv[i]);
        }
        else if (!strcmp(argv[i], "--clock") || !strcmp(argv[i], "--clk") || !strcmp(argv[i], "-clk"))
        {
            if (++i >= argc) return FALSE;
            cfg->clock = atoi(argv[i]);
        }
        else if (!strcmp(argv[i], "--notify") || !strcmp(argv[i], "--n") || !strcmp(argv[i], "-n"))
        {
            if (++i >= argc) return FALSE;
            cfg->notify = atoi(argv[i]);
        }
        else
        {
            printf("Unknown argument: %s\n", argv[i]);
            return FALSE;
        }
    }
    return TRUE;
}

//////////////////////////////////////////////////////////
// Detect FT600 vs FT601
//////////////////////////////////////////////////////////
void DetectDeviceType(FT_60XCONFIGURATION *cfg)
{
    if (cfg->ProductID == 0x601F)
        printf("Detected Device: FT600 (16-bit)\n");
    else if (cfg->ProductID == 0x601E)
        printf("Detected Device: FT601 (32-bit)\n");
    else
        printf("Unknown FT60x Device (PID: 0x%04X)\n", cfg->ProductID);
}

//////////////////////////////////////////////////////////
// Backup config
//////////////////////////////////////////////////////////
int BackupConfiguration(FT_60XCONFIGURATION *cfg)
{
    FILE *f = fopen("ft60x_backup.bin", "wb");
    if (!f)
    {
        printf("Warning: Could not create backup file\n");
        return FALSE;
    }

    fwrite(cfg, sizeof(FT_60XCONFIGURATION), 1, f);
    fclose(f);

    printf("Backup saved: ft60x_backup.bin\n");
    return TRUE;
}

//////////////////////////////////////////////////////////
// Apply user config
//////////////////////////////////////////////////////////
void ApplyUserConfig(FT_60XCONFIGURATION *cfg, USER_CONFIG *user)
{
    // Mode
    if (user->mode == 245)
    {
        cfg->FIFOMode = CONFIGURATION_FIFO_MODE_245;
        cfg->ChannelConfig = CONFIGURATION_CHANNEL_CONFIG_1;
    }
    else
    {
        cfg->FIFOMode = CONFIGURATION_FIFO_MODE_600;

        switch (user->channels)
        {
        case 1: cfg->ChannelConfig = CONFIGURATION_CHANNEL_CONFIG_1; break;
        case 2: cfg->ChannelConfig = CONFIGURATION_CHANNEL_CONFIG_2; break;
        case 4: cfg->ChannelConfig = CONFIGURATION_CHANNEL_CONFIG_4; break;
        default:
            printf("Invalid channel count. Defaulting to 1.\n");
            cfg->ChannelConfig = CONFIGURATION_CHANNEL_CONFIG_1;
        }
    }

    // Clock
    if (user->clock == 66)
        cfg->FIFOClock = CONFIGURATION_FIFO_CLK_66;
    else
        cfg->FIFOClock = CONFIGURATION_FIFO_CLK_100;

    // Clear notification bits
    cfg->OptionalFeatureSupport &=
        ~(CONFIGURATION_OPTIONAL_FEATURE_ENABLENOTIFICATIONMESSAGE_INCHALL);

    // Apply notifications
    if (user->notify)
    {
        if (cfg->ChannelConfig == CONFIGURATION_CHANNEL_CONFIG_1)
            cfg->OptionalFeatureSupport |=
                CONFIGURATION_OPTIONAL_FEATURE_ENABLENOTIFICATIONMESSAGE_INCH1;
        else if (cfg->ChannelConfig == CONFIGURATION_CHANNEL_CONFIG_2)
            cfg->OptionalFeatureSupport |=
                CONFIGURATION_OPTIONAL_FEATURE_ENABLENOTIFICATIONMESSAGE_INCH1 |
                CONFIGURATION_OPTIONAL_FEATURE_ENABLENOTIFICATIONMESSAGE_INCH2;
        else
            cfg->OptionalFeatureSupport |=
                CONFIGURATION_OPTIONAL_FEATURE_ENABLENOTIFICATIONMESSAGE_INCHALL;
    }
}

//////////////////////////////////////////////////////////
// Validate config
//////////////////////////////////////////////////////////
int ValidateConfig(FT_60XCONFIGURATION *cfg)
{
    if (cfg->FIFOMode == CONFIGURATION_FIFO_MODE_245 &&
        cfg->ChannelConfig != CONFIGURATION_CHANNEL_CONFIG_1)
    {
        printf("ERROR: 245 mode only supports 1 channel\n");
        return FALSE;
    }

    if (cfg->FIFOClock != CONFIGURATION_FIFO_CLK_66 &&
        cfg->FIFOClock != CONFIGURATION_FIFO_CLK_100)
    {
        printf("ERROR: Invalid FIFO clock\n");
        return FALSE;
    }

    return TRUE;
}

//////////////////////////////////////////////////////////
// MAIN
//////////////////////////////////////////////////////////
int main(int argc, char **argv)
{
    USER_CONFIG user = {600, 1, 100, 0};

    if (!ParseArgs(argc, argv, &user))
    {
        PrintUsage();
        return -1;
    }

    FT_HANDLE handle;
    FT_STATUS status;

    // Open device
    status = FT_Create(0, FT_OPEN_BY_INDEX, &handle);
    if (FT_FAILED(status))
    {
        printf("Failed to open device\n");
        return -1;
    }

    FT_60XCONFIGURATION cfg = {0};

    // Read config
    status = FT_GetChipConfiguration(handle, &cfg);
    if (FT_FAILED(status))
    {
        printf("Failed to read configuration\n");
        FT_Close(handle);
        return -1;
    }

    // Detect device
    DetectDeviceType(&cfg);

    // EEPROM validity check
    if (cfg.FlashEEPROMDetection &
        (1 << CONFIGURATION_FLASH_ROM_BIT_CUSTOMDATA_INVALID))
    {
        printf("ERROR: Invalid EEPROM config. Aborting.\n");
        FT_Close(handle);
        return -1;
    }

    // Backup
    BackupConfiguration(&cfg);

    // Apply user config
    ApplyUserConfig(&cfg, &user);

    // Validate
    if (!ValidateConfig(&cfg))
    {
        printf("Invalid configuration. Abort.\n");
        FT_Close(handle);
        return -1;
    }

    printf("Flashing configuration...\n");

    // Write config
    status = FT_SetChipConfiguration(handle, &cfg);
    if (FT_FAILED(status))
    {
        printf("Write failed: 0x%x\n", status);
        FT_Close(handle);
        return -1;
    }

    FT_Close(handle);

    printf("Success! Device rebooting...\n");

    // Required delay
    sleep(3);

    printf("Re-opening device...\n");

    status = FT_Create(0, FT_OPEN_BY_INDEX, &handle);
    if (FT_FAILED(status))
    {
        printf("Re-open failed (device still rebooting)\n");
        return 0;
    }

    printf("Device ready.\n");

    // Verify and print configuration
    status = FT_GetChipConfiguration(handle, &cfg);
    if (status == FT_OK)
    {
        printf("\nCurrent Configuration:\n");
        printf("  FIFO Mode : %s\n", cfg.FIFOMode == CONFIGURATION_FIFO_MODE_245 ? "245 Mode" : "600 Mode");
        
        const char *ch_str = "Unknown";
        if (cfg.ChannelConfig == CONFIGURATION_CHANNEL_CONFIG_1) ch_str = "1 Channel";
        else if (cfg.ChannelConfig == CONFIGURATION_CHANNEL_CONFIG_2) ch_str = "2 Channels";
        else if (cfg.ChannelConfig == CONFIGURATION_CHANNEL_CONFIG_4) ch_str = "4 Channels";
        printf("  Channels  : %s\n", ch_str);

        const char *clk_str = "Unknown";
        if (cfg.FIFOClock == CONFIGURATION_FIFO_CLK_66) clk_str = "66 MHz";
        else if (cfg.FIFOClock == CONFIGURATION_FIFO_CLK_100) clk_str = "100 MHz";
        else if (cfg.FIFOClock == CONFIGURATION_FIFO_CLK_50) clk_str = "50 MHz";
        else if (cfg.FIFOClock == CONFIGURATION_FIFO_CLK_40) clk_str = "40 MHz";
        printf("  Clock     : %s\n", clk_str);
        
        int bNotify = (cfg.OptionalFeatureSupport & CONFIGURATION_OPTIONAL_FEATURE_ENABLENOTIFICATIONMESSAGE_INCHALL) != 0;
        if (!bNotify) bNotify = (cfg.OptionalFeatureSupport & CONFIGURATION_OPTIONAL_FEATURE_ENABLENOTIFICATIONMESSAGE_INCH1) != 0;
        printf("  Notify    : %s\n", bNotify ? "Enabled" : "Disabled");

        int bIgnoreUnderrun = (cfg.OptionalFeatureSupport & CONFIGURATION_OPTIONAL_FEATURE_DISABLECANCELSESSIONUNDERRUN) != 0;
        printf("  Session Underrun: %s\n\n", bIgnoreUnderrun ? "Ignored" : "Cancel Session (Default)");
    }

    FT_Close(handle);

    return 0;
}
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <stdint.h>

#ifdef _WIN32
	#include "FTD3XX.h"
#else
	#include "ftd3xx.h"
#endif

FT_STATUS Status = FT_OK;
DWORD DeviceCount = 0;
FT_DEVICE_LIST_INFO_NODE *DeviceList = NULL;
FT_HANDLE *HandleList = NULL;
FT_DEVICE_DESCRIPTOR DeviceDescriptor;
FT_CONFIGURATION_DESCRIPTOR ConfigurationDescriptor;
FT_INTERFACE_DESCRIPTOR InterfaceDescriptor;
FT_PIPE_INFORMATION PipeInformation;

char *DESCRIPTOR_TYPE[] = {
	"INVALID", //0
	"DEVICE",
	"CONFIGURATION",
	"STRING",
	"INTERFACE",
	"ENDPOINT",
	"DEVICE_QUALIFIER",
	"OTHER_SPEED_CONFIGURATION",
	"INTERFACE_POWER" //8
};

static size_t Utf16ToUtf8(char *dst, size_t dst_size, const uint16_t *src, size_t src_len)
{
	size_t out = 0;

	if(!dst || (dst_size == 0))
	{
		return 0;
	}

	dst[0] = '\0';

	if(!src)
	{
		return 0;
	}

	for(size_t i = 0; i < src_len; ++i)
	{
		uint32_t codepoint = src[i];

		if(codepoint == 0)
		{
			break;
		}

		if((codepoint >= 0xD800u) && (codepoint <= 0xDBFFu))
		{
			if((i + 1) < src_len)
			{
				uint32_t low = src[i + 1];
				if((low >= 0xDC00u) && (low <= 0xDFFFu))
				{
					codepoint = 0x10000u + (((codepoint - 0xD800u) << 10) | (low - 0xDC00u));
					++i;
				}
				else
				{
					codepoint = 0xFFFDu;
				}
			}
			else
			{
				codepoint = 0xFFFDu;
			}
		}
		else if((codepoint >= 0xDC00u) && (codepoint <= 0xDFFFu))
		{
			codepoint = 0xFFFDu;
		}

		if(codepoint <= 0x7Fu)
		{
			if((out + 1) >= dst_size) { break; }
			dst[out++] = (char)codepoint;
		}
		else if(codepoint <= 0x7FFu)
		{
			if((out + 2) >= dst_size) { break; }
			dst[out++] = (char)(0xC0u | ((codepoint >> 6) & 0x1Fu));
			dst[out++] = (char)(0x80u | (codepoint & 0x3Fu));
		}
		else if(codepoint <= 0xFFFFu)
		{
			if((out + 3) >= dst_size) { break; }
			dst[out++] = (char)(0xE0u | ((codepoint >> 12) & 0x0Fu));
			dst[out++] = (char)(0x80u | ((codepoint >> 6) & 0x3Fu));
			dst[out++] = (char)(0x80u | (codepoint & 0x3Fu));
		}
		else if(codepoint <= 0x10FFFFu)
		{
			if((out + 4) >= dst_size) { break; }
			dst[out++] = (char)(0xF0u | ((codepoint >> 18) & 0x07u));
			dst[out++] = (char)(0x80u | ((codepoint >> 12) & 0x3Fu));
			dst[out++] = (char)(0x80u | ((codepoint >> 6) & 0x3Fu));
			dst[out++] = (char)(0x80u | (codepoint & 0x3Fu));
		}
		else
		{
			if((out + 3) >= dst_size) { break; }
			dst[out++] = (char)0xEFu;
			dst[out++] = (char)0xBFu;
			dst[out++] = (char)0xBDu;
		}
	}

	dst[out] = '\0';
	return out;
}

static size_t StringDescriptorToUtf8(char *dst, size_t dst_size, const FT_STRING_DESCRIPTOR *descriptor)
{
	if(!descriptor)
	{
		if(dst && (dst_size > 0)) { dst[0] = '\0'; }
		return 0;
	}

	size_t code_units = 0;
	if(descriptor->bLength > 2)
	{
		code_units = (size_t)((descriptor->bLength - 2) / 2);
	}

	const size_t max_code_units = sizeof(descriptor->szString) / sizeof(descriptor->szString[0]);
	if(code_units > max_code_units)
	{
		code_units = max_code_units;
	}

	return Utf16ToUtf8(dst, dst_size, (const uint16_t *)descriptor->szString, code_units);
}

FT_STATUS PrintStringAtIndex(FT_HANDLE Handle, UCHAR StringIndex)
{
	FT_STRING_DESCRIPTOR StringDescriptor = {0};

	if(StringIndex == 0)
	{
		return FT_OK;
	}

	FT_STATUS Status = FT_GetStringDescriptor(Handle, StringIndex, &StringDescriptor);
	if(Status != FT_OK)
	{
		return Status;
	}

	char String[1024] = {'\0'};
	(void)StringDescriptorToUtf8(String, sizeof(String), &StringDescriptor);
	printf("%s", String);
	return Status;
}

/*
	Frees an array created by NewStringArray.
*/
void FreeStringArray(char **OldArray)
{
	int i = 0;
	if(OldArray) //Last element in this array is a null ptr.
	{
		i = 0;
		while(OldArray[i])
		{
			//printf("FREE %i: %p\n", i, OldArray[i]);
			free(OldArray[i]);
			++i;
		}
		free(OldArray);
	}
}

/*
	Allocates a array[Size] of strings Length chars long.
*/
char **NewStringArray(int Size, int Length)
{
	char **NewArray = NULL;
	NewArray = malloc(sizeof(char *) * (Size+1));
	if(NewArray)
	{
		NewArray[Size] = NULL; //Array must be NULL terminated.
		for(int i = 0; i < Size; ++i)
		{
			NewArray[i] = malloc(sizeof(char) * Length);
			//printf("New %i: %p\n", i, NewArray[i]);
			if(!NewArray[i])
			{ //Failed a malloc, free all previous mallocs and return NULL.
				FreeStringArray(NewArray);
				NewArray = NULL;
				break;
			}
		}
		//printf("NULL %i: %p\n", Size, NewArray[Size]);
	}
	return NewArray;
}

void EarlyExit()
{
	if(DeviceList){free(DeviceList);}
	if(HandleList) //We assume all handles are open.
	{
		for(DWORD i = 0; i < DeviceCount; ++i){FT_Close(HandleList[i]);}
		free(HandleList);
	}
	printf("EXIT\n");
	exit(0);
}

int main()
{
	DWORD ConnectedCount = 0;
	DWORD Flags = 0; DWORD Type = 0;
	DWORD ID = 0; DWORD LocId = 0;
	char SerialNumber[17] = {0}; //Add extra char for end of string char in edge cases.
	char Description[33] = {0};
	FT_HANDLE Handle = NULL;
	char **StringArray = NULL; //To hold an array of strings.
	DWORD Version;
	Status = FT_GetLibraryVersion(&Version);
	if(Status != FT_OK){printf("FT_GetLibraryVersion = %i: Quitting early\n", Status); EarlyExit();}
	printf("Library Version = 0x%08x\n", Version);
	Status = FT_CreateDeviceInfoList(&DeviceCount);
	if((Status != FT_OK) || (DeviceCount < 1))
	{
		printf("FT_CreateDeviceInfoList = %i: DeviceCount = %i\n", Status, DeviceCount);
		EarlyExit();
	}

	if(DeviceCount > INT_MAX)
	{
		printf("ERROR: DeviceCount too large: %u\n", (unsigned)DeviceCount);
		EarlyExit();
	}
	const int deviceCount = (int)DeviceCount;

	printf("Detected %i devices!\n", DeviceCount);
	DeviceList = malloc(sizeof(FT_DEVICE_LIST_INFO_NODE) * DeviceCount);
	if(!DeviceList){printf("DeviceList: malloc = %p:\n", (void*)DeviceList); EarlyExit();}
	Status = FT_GetDeviceInfoList(DeviceList, &ConnectedCount);
	if((Status != FT_OK) || (ConnectedCount != DeviceCount))
	{printf("FT_GetDeviceInfoList = %i: DevCount(%i) vs ConCount(%i)\n", Status, DeviceCount, ConnectedCount); free(HandleList); HandleList = NULL; EarlyExit();}
	printf("DevCount(%i) vs. ConCount(%i)\n", DeviceCount, ConnectedCount);
	if(DeviceCount != ConnectedCount){printf("ERROR: DevCount(%i) != ConCount(%i)\n", DeviceCount, ConnectedCount); EarlyExit(); }

	printf("\n---| FT_GetDeviceInfoList vs. FT_ListDevices |---\n");
	Status = FT_ListDevices(&ConnectedCount,NULL,FT_LIST_NUMBER_ONLY);
	if(Status != FT_OK){printf("FT_ListDevices(FT_LIST_NUMBER_ONLY) = %i: Quitting early\n",Status); EarlyExit();}
	printf("DevCount(%i) vs. ConCount(%i)\n", DeviceCount, ConnectedCount);
	if(DeviceCount != ConnectedCount){printf("ERROR: DevCount(%i) != ConCount(%i)\n", DeviceCount, ConnectedCount); EarlyExit();}
	for(int i = 0; i < deviceCount; ++i) //Check serial numbers.
	{
		Status = FT_ListDevices((PVOID)(uintptr_t)i, SerialNumber, FT_LIST_BY_INDEX | FT_OPEN_BY_SERIAL_NUMBER);
		if(Status != FT_OK){printf("FT_ListDevices(FT_LIST_BY_INDEX | FT_OPEN_BY_SERIAL_NUMBER) = %i: Quitting early\n", Status); EarlyExit();}
		SerialNumber[16] = '\0'; //Null terminate just in case.
		for(int j = i; j < deviceCount; ++j) //Check for any matches.
		{
			printf("SerialNumber[%i]vs[%i]:\t[%-16s]\t| [%-16s]\t| ", j, i, DeviceList[j].SerialNumber, SerialNumber);
			if(strncmp(DeviceList[j].SerialNumber, SerialNumber,16))
			{printf("UNEQUAL\n");if(j + 1 == deviceCount){j = -1;}}else{printf("MATCH\n"); break;}
			if((j + 1)%deviceCount == i) //Found no matching device!
			{printf("NO MATCHING SERIALNUMBER: Quitting early\n"); EarlyExit();}
		}
	}
	for(int i = 0; i < deviceCount; ++i) //Check descriptions.
	{
		Status = FT_ListDevices((PVOID)(uintptr_t)i, Description, FT_LIST_BY_INDEX | FT_OPEN_BY_DESCRIPTION);
		if(Status != FT_OK){printf("FT_ListDevices(FT_LIST_BY_INDEX | FT_OPEN_BY_DESCRIPTION) = %i: Quitting early\n", Status); EarlyExit();}
		Description[32] = '\0'; //Null terminate just in case.
		for(int j = i; j < deviceCount; ++j) //Check for any matches.
		{
			printf("Description[%i]vs[%i]:\t[%-32s]\t| [%-32s]\t| ", j, i, DeviceList[j].Description, Description);
			if(strncmp(DeviceList[j].Description, Description, 32))
			{printf("UNEQUAL\n");if(j + 1 == deviceCount){j = -1;}}else{printf("MATCH\n"); break;}
			if((j + 1)%deviceCount == i) //Found no matching device!
			{printf("NO MATCHING DESCRIPTION: Quitting early\n"); EarlyExit();}
		}
	}

	printf("\n---| FT_GetDeviceInfoList vs. FT_ListDevices(FT_LIST_ALL) |---\n");
	StringArray = NewStringArray(deviceCount, 33);
	if(!StringArray){printf("Failed to allocate string array.\n"); EarlyExit();}
	Status = FT_ListDevices(StringArray, &ConnectedCount, FT_LIST_ALL | FT_OPEN_BY_SERIAL_NUMBER);
	if(Status != FT_OK)
	{
		printf("FT_ListDevices(FT_LIST_ALL | FT_OPEN_BY_SERIAL_NUMBER) = %i: Quitting early\n", Status);
		FreeStringArray(StringArray); EarlyExit();
	}
	printf("DevCount(%i) vs. ConCount(%i)\n",DeviceCount,ConnectedCount);
	if(DeviceCount != ConnectedCount){ printf("ERROR: DevCount(%i) != ConCount(%i)\n", DeviceCount, ConnectedCount); FreeStringArray(StringArray); EarlyExit();}
	for(int i = 0; i < deviceCount; ++i)
	{
		for(int j = i; j < deviceCount; ++j) //Check for any matches.
		{
			printf("SerialNumber[%i]vs[%i]:\t[%-16s]\t| [%-16s]\t| ", j, i, DeviceList[j].SerialNumber, StringArray[i]);
			if(strncmp(DeviceList[j].SerialNumber, StringArray[i], 16))
			{printf("UNEQUAL\n");if(j + 1 == deviceCount){j = -1;}}else{printf("MATCH\n"); break;}
			if((j + 1)%deviceCount == i) //Found no matching device!
			{printf("NO MATCHING SERIALNUMBER: Quitting early\n"); EarlyExit();}
		}
	}
	Status = FT_ListDevices(StringArray, &ConnectedCount, FT_LIST_ALL | FT_OPEN_BY_DESCRIPTION);
	if(Status != FT_OK)
	{
		printf("FT_ListDevices(FT_LIST_ALL | FT_OPEN_BY_DESCRIPTION) = %i: Quitting early\n", Status);
		FreeStringArray(StringArray); EarlyExit();
	}
	printf("DevCount(%i) vs. ConCount(%i)\n",DeviceCount,ConnectedCount);
	if(DeviceCount != ConnectedCount){ printf("ERROR: DevCount(%i) != ConCount(%i)\n", DeviceCount, ConnectedCount); FreeStringArray(StringArray); EarlyExit();}
	for(int i = 0; i < deviceCount; ++i)
	{
		for(int j = i; j < deviceCount; ++j) //Check for any matches.
		{
			printf("Description[%i]vs[%i]:\t[%-32s]\t| [%-32s]\t| ", j, i, DeviceList[j].Description, StringArray[i]);
			if(strncmp(DeviceList[j].Description, StringArray[i], 32))
			{printf("UNEQUAL\n");if(j + 1 == deviceCount){j = -1;}}else{printf("MATCH\n"); break;}
			if((j + 1)%deviceCount == i) //Found no matching device!
			{printf("NO MATCHING DESCRIPTION: Quitting early\n"); EarlyExit();}
		}
	}
	FreeStringArray(StringArray); StringArray = NULL;

	printf("\n---| FT_Create |---\n");
	HandleList = malloc(sizeof(FT_HANDLE) * DeviceCount);
	if(!HandleList){ printf("HandleList: malloc = %p:\n",(void*)HandleList); EarlyExit();}
	for(int i = 0; i < deviceCount; ++i)
	{
		printf("Checking Device %i [%i]: %s\n", i, DeviceList[i].Type, DeviceList[i].Description);
		if(DeviceList[i].Flags == FT_FLAGS_OPENED)
		{
			printf("Device %i is already open in another process!\n", i);
			for(int j = 0; j < i; ++j){ FT_Close(HandleList[j]); } //Close any devices that were open.
			free(HandleList); HandleList = NULL; EarlyExit();
		}
		Status = FT_Create((PVOID)(uintptr_t)i, FT_OPEN_BY_INDEX, &HandleList[i]);
		if(Status != FT_OK)
		{
			printf("FT_Create = %i: Quitting early\n", Status);
			for(int j = 0; j < i; ++j){FT_Close(HandleList[j]);} //Close any devices that were open.
			free(HandleList); HandleList = NULL; EarlyExit();
		}
		printf("Successfully opened Device %i!\n", i);
	}

	printf("\n---| FT_GetDeviceInfoList vs. FT_GetDeviceInfoDetail |---\n");
	for(int i = 0; i < deviceCount; ++i)
	{
		printf(":: Device %i [%i]: %s ::\n", i, DeviceList[i].Type, DeviceList[i].Description);
		Status = FT_GetDeviceInfoDetail(i, &Flags, &Type,
											&ID, &LocId,
											SerialNumber, Description,
											&Handle);
		if(Status != FT_OK){printf("FT_GetDeviceInfoDetail = %i: Quitting early\n", Status); EarlyExit();}
		SerialNumber[16] = '\0'; Description[32] = '\0'; //Null terminate strings just in case.
		printf("\tFT_GDIL\t\t\t| FT_GDID\n");
		printf("\tField:\t10C-Value\t| 10C-Value\t| Human Interpretation\n");
		printf("\tFlags:\t0x%08x\t| 0x%08x\t| ", DeviceList[i].Flags, Flags);
		printf("%s", (Flags & FT_FLAGS_SUPERSPEED) ? "3.0 SuperSpeed - " :
						(Flags & FT_FLAGS_HISPEED) ? "2.0 High Speed - " :
						"2.0 Full Speed - ");
		printf("%s\n", (Flags & FT_FLAGS_OPENED) ? "Opened by another process" : "Not opened by another process");
		if(DeviceList[i].Flags != Flags){printf("FLAGS NOT EQUAL: Quitting early\n"); EarlyExit();}
		printf("\tType:\t0d%08i\t| 0d%08i\t| ", DeviceList[i].Type, Type);
		printf("%i\n", Type);
		if(DeviceList[i].Type != Type){printf("TYPE NOT EQUAL: Quitting early\n"); EarlyExit();}
		printf("\tID:\t0x%08x\t| 0x%08x\t| ", DeviceList[i].ID, ID);
		printf("0x%x\n", ID);
		if(DeviceList[i].ID != ID){printf("ID NOT EQUAL: Quitting early\n"); EarlyExit();}
		printf("\tLocId:\t0x%08x\t| 0x%08x\t| ",DeviceList[i].LocId, LocId);
		printf("%i\n", LocId);
		if(DeviceList[i].LocId != LocId){printf("LOCID NOT EQUAL: Quitting early\n"); EarlyExit();}
		printf("\tSerNum:\t%.7s...\t| %.7s...\t| ", DeviceList[i].SerialNumber, SerialNumber);
		printf("'%s'\n", SerialNumber);
		if(strncmp(DeviceList[i].SerialNumber, SerialNumber, 16)){printf("SERIALNUMBER NOT EQUAL: Quitting early\n"); EarlyExit();}
		printf("\tDesc:\t%.7s...\t| %.7s...\t| ",DeviceList[i].Description, Description);
		printf("'%s'\n", Description);
		if(strncmp(DeviceList[i].Description, Description, 16)){printf("Description NOT EQUAL: Quitting early\n"); EarlyExit();}
		//DeviceList handle was not valid as device was not opened by us yet.
		printf("\tHandle:\t%p\t| %p\t| ", (void*)HandleList[i], (void*)Handle);
		printf("%p\n", (void*)HandleList[i]);
		if(HandleList[i] != Handle){printf("ERROR: HANDLE NOT EQUAL MOVING ON...\n");}
		printf("\n");
	}

	printf("\n---| FT_GetDeviceDescriptor |---\n");
	for(int i = 0; i < deviceCount; ++i)
	{
		printf(":: Device %i [%i]: %s ::\n",i,DeviceList[i].Type,DeviceList[i].Description);
		Status = FT_GetDeviceDescriptor(HandleList[i], &DeviceDescriptor);
		if(Status != FT_OK){printf("FT_GetDeviceDescriptor(Handle[%i]) = %i: Quitting early\n", i, Status); EarlyExit();}
		printf("bLength:\t\t0x%04x | Descriptor length = %i\n", DeviceDescriptor.bLength, DeviceDescriptor.bLength);
		printf("bDescriptorType:\t0x%04x | %s DESCRIPTOR\n", DeviceDescriptor.bDescriptorType,
													(DeviceDescriptor.bDescriptorType > 0) && (DeviceDescriptor.bDescriptorType < 8) ? DESCRIPTOR_TYPE[DeviceDescriptor.bDescriptorType] : "UNKNOWN");
		printf("bcdUSB:\t\t\t0x%04x | USB %i.%i (sub-minor version %i)\n", DeviceDescriptor.bcdUSB,
																		(DeviceDescriptor.bcdUSB >> 8) & 0x00FF,
																		(DeviceDescriptor.bcdUSB >> 4) & 0x000F,
																		(DeviceDescriptor.bcdUSB & 0x000F));
		printf("bDeviceClass:\t\t0x%04x\n", DeviceDescriptor.bDeviceClass);
		printf("bDeviceSubClass:\t0x%04x\n", DeviceDescriptor.bDeviceSubClass);
		printf("bDeviceProtocol:\t0x%04x\n", DeviceDescriptor.bDeviceProtocol);
		printf("bMaxPacketSize0:\t0x%04x | Endpoint 0 Max Packet Size = %i\n", DeviceDescriptor.bMaxPacketSize0, DeviceDescriptor.bMaxPacketSize0);
		printf("bMaxPacketSize0:\t0x%04x | Endpoint 0 Max Packet Size = %i\n", DeviceDescriptor.bMaxPacketSize0,DeviceDescriptor.bMaxPacketSize0);
		printf("idVendor:\t\t0x%04x\n", DeviceDescriptor.idVendor);
		printf("idProduct:\t\t0x%04x\n", DeviceDescriptor.idProduct);
		printf("bcdDevice:\t\t0x%04x\n", DeviceDescriptor.bcdDevice);
		printf("iManufacturer:\t\t0x%04x | Manufacturer\t= '", DeviceDescriptor.iManufacturer);
		Status = PrintStringAtIndex(HandleList[i], DeviceDescriptor.iManufacturer);
		printf("'\n");
		if(Status != FT_OK){printf("PrintStringAtIndex(Handle[%i], %i) = %i: Quitting early\n", i, DeviceDescriptor.iManufacturer, Status); EarlyExit();}
		printf("iProduct:\t\t0x%04x | Description\t= '", DeviceDescriptor.iProduct);
		Status = PrintStringAtIndex(HandleList[i], DeviceDescriptor.iProduct);
		printf("'\n");
		if(Status != FT_OK){printf("PrintStringAtIndex(Handle[%i], %i) = %i: Quitting early\n", i, DeviceDescriptor.iProduct, Status); EarlyExit();}
		printf("iSerialNumber:\t\t0x%04x | SerialNumber\t= '", DeviceDescriptor.iSerialNumber);
		Status = PrintStringAtIndex(HandleList[i], DeviceDescriptor.iSerialNumber);
		printf("'\n");
		if(Status != FT_OK){printf("PrintStringAtIndex(Handle[%i], %i) = %i: Quitting early\n", i, DeviceDescriptor.iSerialNumber, Status); EarlyExit();}
		printf("bNumConfigurations:\t0x%04x | %i Other-speed Configuration/s\n", DeviceDescriptor.bNumConfigurations, DeviceDescriptor.bNumConfigurations);
		printf("\n");
	}

	printf("\n---| FT_GetConfigurationDescriptor |---\n");
	for(int i = 0; i < deviceCount; ++i)
	{
		printf(":: Device %i [%i]: %s ::\n", i, DeviceList[i].Type, DeviceList[i].Description);
		Status = FT_GetConfigurationDescriptor(HandleList[i], &ConfigurationDescriptor);
		if(Status != FT_OK){printf("FT_GetConfigurationDescriptor(Handle[%i]) = %i: Quitting early\n", i, Status); EarlyExit();}
		printf("bLength:\t\t0x%04x | Descriptor length = %i\n", ConfigurationDescriptor.bLength, ConfigurationDescriptor.bLength);
		printf("bDescriptorType:\t0x%04x | %s DESCRIPTOR\n", ConfigurationDescriptor.bDescriptorType,
													(ConfigurationDescriptor.bDescriptorType > 0) && (ConfigurationDescriptor.bDescriptorType < 8) ? DESCRIPTOR_TYPE[ConfigurationDescriptor.bDescriptorType] : "UNKNOWN");
		printf("wTotalLength:\t\t0x%04x | Total configuration data length = %i\n", ConfigurationDescriptor.wTotalLength, ConfigurationDescriptor.wTotalLength);
		printf("bNumInterfaces:\t\t0x%04x | %i Interfaces\n", ConfigurationDescriptor.bNumInterfaces, ConfigurationDescriptor.bNumInterfaces);
		printf("bConfigurationValue:\t0x%04x | Configuration value = %i\n", ConfigurationDescriptor.bConfigurationValue, ConfigurationDescriptor.bConfigurationValue);
		printf("iConfiguration:\t\t0x%04x | Configuration = '", ConfigurationDescriptor.iConfiguration);
		Status = PrintStringAtIndex(HandleList[i], ConfigurationDescriptor.iConfiguration);
		printf("'\n");
		if(Status != FT_OK){printf("PrintStringAtIndex(Handle[%i], %i) = %i: Quitting early\n", i, ConfigurationDescriptor.iConfiguration, Status); EarlyExit();}
		printf("bmAttributes:\t\t0x%04x | Characteristics = ", ConfigurationDescriptor.bmAttributes);
		if(ConfigurationDescriptor.bmAttributes & 0x40){printf("self-powered");}
		else if(ConfigurationDescriptor.bmAttributes & 0x80){ printf("bus-powered");}
		if(ConfigurationDescriptor.bmAttributes & 0x20){printf(" & remote wakeup enabled");}
		printf("\n");
		printf("MaxPower:\t\t0x%04x | Max Power = %i mA\n", ConfigurationDescriptor.MaxPower, ConfigurationDescriptor.MaxPower * 8);
		printf("\n");
	}

	printf("\n---| FT_GetInterfaceDescriptor(Interface 1) |---\n");
	for(int i = 0; i < deviceCount; ++i)
	{
		printf(":: Device %i [%i]: %s ::\n", i, DeviceList[i].Type, DeviceList[i].Description);
		Status = FT_GetInterfaceDescriptor(HandleList[i], 1, &InterfaceDescriptor);
		if(Status != FT_OK){printf("FT_GetInterfaceDescriptor(Handle[%i]) = %i: Quitting early\n", i, Status); EarlyExit();}
		printf("bLength:\t\t0x%04x | Descriptor length = %i\n", InterfaceDescriptor.bLength, InterfaceDescriptor.bLength);
		printf("bDescriptorType:\t0x%04x | %s DESCRIPTOR\n", InterfaceDescriptor.bDescriptorType,
													(InterfaceDescriptor.bDescriptorType > 0) && (InterfaceDescriptor.bDescriptorType < 8) ? DESCRIPTOR_TYPE[InterfaceDescriptor.bDescriptorType] : "UNKNOWN");
		printf("bInterfaceNumber:\t0x%04x | Interface number = %i\n", InterfaceDescriptor.bInterfaceNumber, InterfaceDescriptor.bInterfaceNumber);
		printf("bAlternateSetting:\t0x%04x | Alternate setting %i\n", InterfaceDescriptor.bAlternateSetting, InterfaceDescriptor.bAlternateSetting);
		printf("bNumEndpoints:\t\t0x%04x | %i Endpoints\n", InterfaceDescriptor.bNumEndpoints, InterfaceDescriptor.bNumEndpoints);
		printf("bInterfaceClass:\t0x%04x\n", InterfaceDescriptor.bInterfaceClass);
		printf("bInterfaceSubClass:\t0x%04x\n", InterfaceDescriptor.bInterfaceSubClass);
		printf("bInterfaceProtocol:\t0x%04x\n", InterfaceDescriptor.bInterfaceProtocol);
		printf("iInterface:\t\t0x%04x | Interface = '", InterfaceDescriptor.iInterface);
		Status = PrintStringAtIndex(HandleList[i], InterfaceDescriptor.iInterface);
		printf("'\n");
		if(Status != FT_OK){printf("PrintStringAtIndex(Handle[%i], %i) = %i: Quitting early\n", i, InterfaceDescriptor.iInterface, Status); EarlyExit();}
		printf("\n");
	}

	printf("\n---| FT_GetPipeInformation |---\n");
	for(int i = 0; i < deviceCount; ++i)
	{
		printf(":: Device %i [%i]: %s ::\n", i, DeviceList[i].Type, DeviceList[i].Description);
		Status = FT_GetInterfaceDescriptor(HandleList[i], 1, &InterfaceDescriptor); //Get the number of endpoints.
		if(Status != FT_OK){printf("FT_GetInterfaceDescriptor(Handle[%i]) = %i: Quitting early\n", i, Status); EarlyExit();}
		printf("%i Total Pipes/Endpoints\n", InterfaceDescriptor.bNumEndpoints);
		for(int j = 0; j < InterfaceDescriptor.bNumEndpoints; ++j)
		{
			printf("__[Pipe/endpoint %i]__\n", j);
			Status = FT_GetPipeInformation(HandleList[i], 1, j, &PipeInformation); //Get the number of endpoints.
			if(Status != FT_OK){printf("FT_GetPipeInformation(Handle[%i]) = %i: Quitting early\n", i, Status); EarlyExit();}
			printf("\tPipeType:\t0x%04x | %s Pipe/endpoint\n", PipeInformation.PipeType, (PipeInformation.PipeType == 0) ? "Control" :
																							(PipeInformation.PipeType == 1) ? "Isochronous" :
																							(PipeInformation.PipeType == 2) ? "Bulk" :
																							(PipeInformation.PipeType == 3) ? "Interrupt" : "Unknown");
			printf("\tPipeId:\t\t0x%04x | %s Pipe/endpoint\n", PipeInformation.PipeId, (PipeInformation.PipeId & 0x80) ? "IN" : "OUT");
			printf("\tMaxPacketSize:\t0x%04x | Max packet size = %i bytes\n", PipeInformation.MaximumPacketSize, PipeInformation.MaximumPacketSize);
			printf("\tInterval:\t0x%04x | Interval = %i\n", PipeInformation.Interval, PipeInformation.Interval);
		}
		printf("\n");
	}

	printf("Press ENTER to finish.\n");
	getchar();
	printf("---| PROGRAM SUCCESSFULLY COMPLETED |---\n");
	EarlyExit();
	return 0;
}

#define _GNU_SOURCE
#ifdef __APPLE__
#undef _POSIX_C_SOURCE
#define _DARWIN_C_SOURCE
#endif
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#ifdef _WIN32
#include "FTD3XX.h"
#include <processthreadsapi.h>
#else
#include "Types.h"
#include "ftd3xx.h"
#include <errno.h>
#include <pthread.h>
#include <unistd.h>
#define CRITICAL_SECTION pthread_mutex_t
#define InitializeCriticalSection(A) pthread_mutex_init(A, 0)
#define EnterCriticalSection pthread_mutex_lock
#define TryEnterCriticalSection pthread_mutex_trylock
#define LeaveCriticalSection pthread_mutex_unlock
#define DeleteCriticalSection pthread_mutex_destroy
#endif

//---| EDITABLE/TESTING DEFINES |---
#define THREAD_COUNT		80 //Number of read AND write threads to make for EACH channel. E.g. THREAD_COUNT*CHANNEL*2 threads.
#define CHANNEL_COUNT		4 //Number of channels to make THREAD_COUNT*2 threads.
#define REQUEST_SIZE		16*1024 //Size of read/write requests.
#define CHECK_DATA			1 //If non-zero, reader threads will check incoming data with matching writer thread.
#define RANDOM_DATA			1 //If non-zero, guarantee each write buffer byte (excluding ThreadNumber bytes) are randomized.
#define DISABLE_TIMEOUTS	0 //If non-zero, timeouts are disabled for all channels.
#define PRINT_ABORTS		0 //If non-zero, threads will print there error status messages if they ended due to FT_OPERATION_ABORTED.
//% If non-zero, the status of the thread will be DEAD when FT_AbortPipe is called. Otherwise it will be KILLED.

//---| CONSTANT DEFINES |---
#define THREAD_DIED		0 //Thread ended itself.
#define THREAD_KILLED	1 //Thread killed by main thread.
#define THREAD_ALIVE	2 //Thread is alive.

FT_HANDLE Handle; //The handle all threads use.
CRITICAL_SECTION PrintMutex;
volatile ULONG ProgramStopping = 0;

char *FT_STATUS_STR[] = {
	"FT_OK", //0
	"FT_INVALID_HANDLE",
	"FT_DEVICE_NOT_FOUND",
	"FT_DEVICE_NOT_OPENED",
	"FT_IO_ERROR",
	"FT_INSUFFICIENT_RESOURCES",
	"FT_INVALID_PARAMETER",
	"FT_INVALID_BAUD_RATE",
	"FT_DEVICE_NOT_OPENED_FOR_ERASE",
	"FT_DEVICE_NOT_OPENED_FOR_WRITE",
	"FT_FAILED_TO_WRITE_DEVICE",
	"FT_EEPROM_READ_FAILED",
	"FT_EEPROM_WRITE_FAILED",
	"FT_EEPROM_ERASE_FAILED",
	"FT_EEPROM_NOT_PRESENT",
	"FT_EEPROM_NOT_PROGRAMMED",
	"FT_INVALID_ARGS",
	"FT_NOT_SUPPORTED",
	"FT_NO_MORE_ITEMS",
	"FT_TIMEOUT",
	"FT_OPERATION_ABORTED",
	"FT_RESERVED_PIPE",
	"FT_INVALID_CONTROL_REQUEST_DIRECTION",
	"FT_INVALID_CONTROL_REQUEST_TYPE",
	"FT_IO_PENDING",
	"FT_IO_INCOMPLETE",
	"FT_HANDLE_EOF",
	"FT_BUSY",
	"FT_NO_SYSTEM_RESOURCES",
	"FT_DEVICE_LIST_NOT_READY",
	"FT_DEVICE_NOT_CONNECTED",
	"FT_INCORRECT_DEVICE_PATH",
	"FT_OTHER_ERROR", //32
	"INVALID_ERROR"
};

#ifndef _WIN32
/* Join a thread with a short deadline; cancel and force-join if it stalls.
 * This prevents indefinite hangs when a thread is blocked inside the library. */
static void JoinThreadHandle(HANDLE *ThreadHandle)
{
	if(!ThreadHandle || !*ThreadHandle)
		return;
	pthread_t tid = *((pthread_t *)(*ThreadHandle));
#ifdef __APPLE__
  pthread_join(tid, NULL);
#else
	struct timespec ts;
	clock_gettime(CLOCK_REALTIME, &ts);
	ts.tv_nsec += 100 * 1000 * 1000; /* 100 ms */
	if(ts.tv_nsec >= 1000000000L){ ts.tv_sec++; ts.tv_nsec -= 1000000000L; }
	if(pthread_timedjoin_np(tid, NULL, &ts) == ETIMEDOUT)
	{
		pthread_cancel(tid);
		pthread_join(tid, NULL);
	}
#endif
	free(*ThreadHandle);
	*ThreadHandle = NULL;
}
#endif

typedef struct _ThreadData
{
	HANDLE ThreadHandle; //Handle of the thread.
	DWORD ThreadID; //ThreadID.
	ULONG ThreadNumber; //Which thread this data is from.
	UCHAR Channel; //What FIFO channel to read/write to (FIFOindex). 0 = channel 1. 3 = channel 4.
	BOOL Writer; //If TRUE, this was a writer thread, else it was a reader thread.
	ULONG Dead; //If not THREAD_ALIVE, thread has ended.
	ULONG Iteration; //Last iteration of the thread loop. 0 = first iteration.
	FT_STATUS Status; //Status of last FT function call if it completed.
	OVERLAPPED Overlap;
	UCHAR Buffer[REQUEST_SIZE];
	ULONG BytesTransferred; //BytesTransferred from last read/write pipe call.
	PVOID FT_LastFunction; //FT function called before error. Is set before calling function.
	struct _ThreadData* ThreadArray; //Pointer to the main array of threads.
} ThreadData;

/*
	Only prints function strings called in thread function!
	Printable functions manually added in if-else statements.
*/
void PrintThreadStatus(ThreadData *Data)
{
	if((!PRINT_ABORTS) && (Data->Status == FT_OPERATION_ABORTED))
	{
		Data->Dead = THREAD_KILLED; //Thread was likely killed by an abort pipe call.
		return;
	}
	EnterCriticalSection(&PrintMutex);
	printf("---| Thread %-5i (ID = 0x%x) |---\n", Data->ThreadNumber, Data->ThreadID);
	printf("  THREAD STATUS = %s\n", (Data->Dead == THREAD_DIED) ? "DEAD" : (Data->Dead == THREAD_KILLED ? "KILLED" : "ALIVE"));
	printf("  %s to channel %i of %i, endpoint 0x%02x\n", Data->Writer ? "WRITER" : "READER",
											Data->Channel + 1, //Channel 1-4.
											CHANNEL_COUNT, //Number of channels
											(Data->Writer ? 0x02: 0x82) + Data->Channel);
	printf("  Thread Iteration = %i\n", Data->Iteration);
	printf("  BytesTransferred = %i out of expected %i bytes\n", Data->BytesTransferred, REQUEST_SIZE);
	printf("  Last Function = ");
	#ifdef _WIN32
	if(Data->FT_LastFunction == FT_WritePipe){printf("FT_WritePipe");}
	else if(Data->FT_LastFunction == FT_ReadPipe){ printf("FT_ReadPipe"); }
	#else
	if(Data->FT_LastFunction == FT_WritePipeAsync){printf("FT_WritePipeAsync");}
	else if(Data->FT_LastFunction == FT_ReadPipeAsync){printf("FT_ReadPipeAsync");}
	#endif
	else if(Data->FT_LastFunction == FT_GetOverlappedResult){printf("FT_GetOverlappedResult");}
	else{printf("UNKNOWN_FUNCTION");}
	printf("()\n");
	printf("  FT_STATUS Return Code: %s (%i)\n", (Data->Status <= FT_OTHER_ERROR) ? FT_STATUS_STR[Data->Status] : "UNKNOWN ERROR", Data->Status);
	LeaveCriticalSection(&PrintMutex);
	return;
}

static int ShouldTreatThreadExitAsKilled(const ThreadData *Data)
{
	if(!Data)
		return TRUE;
	if((Data->Dead == THREAD_KILLED) || ProgramStopping)
		return TRUE;
	if(Data->Status == FT_OPERATION_ABORTED)
		return TRUE;
	if((Data->FT_LastFunction == FT_GetOverlappedResult) &&
	   ((Data->Status == FT_TIMEOUT) || (Data->BytesTransferred != REQUEST_SIZE)))
		return TRUE;
	return FALSE;
}

static BOOL HandleThreadIoCompletion(ThreadData *Data)
{
	if((Data->Status == FT_OK) && (Data->BytesTransferred == REQUEST_SIZE))
		return TRUE;

	if(ShouldTreatThreadExitAsKilled(Data))
	{
		Data->Dead = THREAD_KILLED;
		return FALSE;
	}

	Data->Dead = THREAD_DIED;
	PrintThreadStatus(Data);
	return FALSE;
}

/*
	Print progress over time.
	Uses CLOCK_MONOTONIC for accurate wall-clock throughput.
	clock() accumulates CPU time across all threads and overflows quickly
	at high thread counts, producing incorrect throughput readings.
*/
ThreadData *PrintProgressThread(ThreadData *Data)
{
	ULONG Iterations = 0;
	double DataThroughput = 0;
	struct timespec ClockStart, ClockEnd;
	double ProgramRuntime = 0;
	clock_gettime(CLOCK_MONOTONIC, &ClockStart);
	int TotalReaders = 0;
	int TotalWriters = 0;
	int DeadReaders = 0;
	int DeadWriters = 0;
	int KilledReaders = 0;
	int KilledWriters = 0;
	while(Data->Dead == THREAD_ALIVE)
	{
		//Print progress about every second.
		#ifdef _WIN32
				Sleep(1000);
		#else
				sleep(1);
		#endif
		Iterations = 0;
		TotalReaders = 0;
		TotalWriters = 0;
		DeadReaders = 0;
		DeadWriters = 0;
		KilledReaders = 0;
		KilledWriters = 0;
		for(int i = 0; Data->ThreadArray[i].ThreadNumber != Data->ThreadNumber; ++i)
		{
			Iterations += Data->ThreadArray[i].Iteration; //Add successful iterations.
			TotalReaders += !Data->ThreadArray[i].Writer;
			TotalWriters += Data->ThreadArray[i].Writer;
			DeadReaders += (Data->ThreadArray[i].Dead == THREAD_DIED) && !Data->ThreadArray[i].Writer;
			DeadWriters += (Data->ThreadArray[i].Dead == THREAD_DIED) && Data->ThreadArray[i].Writer;
			KilledReaders += (Data->ThreadArray[i].Dead == THREAD_KILLED) && !Data->ThreadArray[i].Writer;
			KilledWriters += (Data->ThreadArray[i].Dead == THREAD_KILLED) && Data->ThreadArray[i].Writer;
		}
		//Get total data throughput during wall-clock runtime.
		clock_gettime(CLOCK_MONOTONIC, &ClockEnd);
		ProgramRuntime = (double)(ClockEnd.tv_sec - ClockStart.tv_sec) +
		                 (double)(ClockEnd.tv_nsec - ClockStart.tv_nsec) * 1e-9;
		DataThroughput = (double)(Iterations * REQUEST_SIZE) / (double)1048576.0;
		EnterCriticalSection(&PrintMutex);
		printf("Total Average Throughput ~= %.2lf MiB/s | Total Data Transferred = %.2lf MiB\n", DataThroughput / ProgramRuntime, DataThroughput);
		printf("Readers = %i/%i Alive, %i Dead, %i Killed.\n", TotalReaders - DeadReaders - KilledReaders, TotalReaders, DeadReaders, KilledReaders);
		printf("Writers = %i/%i Alive, %i Dead, %i Killed.\n", TotalWriters - DeadWriters - KilledWriters, TotalWriters, DeadWriters, KilledWriters);
		LeaveCriticalSection(&PrintMutex);
	}
	return Data;
}

/*
	Continuously sends read requests.
*/
ThreadData *ReaderThread(ThreadData *Data)
{
	Data->Writer = FALSE;
	UCHAR *WriteBuffer = NULL; //Pointer to write buffer read request got data from.
	ULONG WriterIndex = 0;
	while(TRUE)
	{
		/* Accumulate bytes until we have a full REQUEST_SIZE buffer.
		 * On Linux the driver may complete a URB with fewer bytes than requested
		 * (short packet) when many readers compete for the same loopback data.
		 * Loop and issue sub-reads into the remaining window rather than treating
		 * a short-read as a fatal error or silently killing the thread. */
		ULONG TotalReceived = 0;
		ULONG SubReads = 0; //Count sub-reads needed to fill REQUEST_SIZE.
		BOOL bError = FALSE;
		while(TotalReceived < (ULONG)REQUEST_SIZE)
		{
			#ifdef _WIN32
				Data->FT_LastFunction = FT_ReadPipe;
				Data->Status = FT_ReadPipe(Handle, 0x82 + Data->Channel,
			#else
				Data->FT_LastFunction = FT_ReadPipeAsync;
				Data->Status = FT_ReadPipeAsync(Handle, Data->Channel, //Linux uses FIFO ID.
			#endif //_WIN32
												Data->Buffer + TotalReceived,
												REQUEST_SIZE - TotalReceived,
												&Data->BytesTransferred, &Data->Overlap);
			if((Data->Status != FT_OK) && (Data->Status != FT_IO_PENDING))
			{
				if(Data->Dead != THREAD_ALIVE){bError = TRUE; break;} //Killed by main — exit silently.
				Data->Dead = THREAD_DIED; PrintThreadStatus(Data); bError = TRUE; break;
			}
			Data->BytesTransferred = 0;
			Data->FT_LastFunction = FT_GetOverlappedResult;
			Data->Status = FT_GetOverlappedResult(Handle, &Data->Overlap, &Data->BytesTransferred, TRUE);
			if(Data->Status != FT_OK)
			{
				/* Re-use the shared heuristic: FT_TIMEOUT, 0-byte results, abort,
				 * or program-stopping are all treated as a silent kill rather than
				 * a hard DEAD (which would print noise and confuse the summary). */
				if(ShouldTreatThreadExitAsKilled(Data))
					Data->Dead = THREAD_KILLED;
				else
					{Data->Dead = THREAD_DIED; PrintThreadStatus(Data);}
				bError = TRUE; break;
			}
			TotalReceived += Data->BytesTransferred;
			++SubReads;
			if(Data->Dead != THREAD_ALIVE){bError = TRUE; break;} //Killed mid-accumulation — exit cleanly.
		}
		if(bError){break;}
		Data->BytesTransferred = TotalReceived;
		if(CHECK_DATA)
		{
			/* Use memcpy to safely read the writer's thread index from the buffer.
			 * Direct ULONG cast of a UCHAR pointer is UB (misaligned) and causes
			 * SIGBUS on strict-alignment architectures. */
			memcpy(&WriterIndex, &Data->Buffer[0], sizeof(WriterIndex));
			/* Guard: skip the integrity check when the buffer cannot reliably
			 * contain exactly one writer's data:
			 *   - THREAD_COUNT > 1: the shared FIFO interleaves all writers, so
			 *     even a single full-size read contains data from multiple writers.
			 *   - SubReads > 1: accumulation pulled from more than one sub-transfer.
			 *   - invalid WriterIndex: garbage in first 4 bytes.
			 *   - even WriterIndex: even threads are readers, not writers. */
			if(THREAD_COUNT > 1 || SubReads > 1 ||
			   WriterIndex >= (ULONG)(THREAD_COUNT * CHANNEL_COUNT * 2) || (WriterIndex & 1) == 0)
			{
				/* Interleaved or multi-read data — skip check this iteration. */
				Data->BytesTransferred = 0;
				++Data->Iteration;
				if(Data->Dead != THREAD_ALIVE){break;}
				continue;
			}
			WriteBuffer = Data->ThreadArray[WriterIndex].Buffer;
			for(int i = 0; i < REQUEST_SIZE; ++i)
			{
				if(WriteBuffer[i] != Data->Buffer[i])
				{
					EnterCriticalSection(&PrintMutex);
					printf("Thread[%i] Mismatch at byte[%i]: WriterThread[%lu] sent 0x%02x, Reader got 0x%02x\n",
								Data->ThreadNumber, i,
								(unsigned long)WriterIndex,
								WriteBuffer[i], Data->Buffer[i]);
					LeaveCriticalSection(&PrintMutex);
					Data->Dead = THREAD_DIED;
					break;
				}
			}
			if(Data->Dead == THREAD_DIED){PrintThreadStatus(Data); break;} //Exit if there was a data mismatch.
		}
		Data->BytesTransferred = 0;
		//Successfully read data. Continue.
		++Data->Iteration;
		if(Data->Dead != THREAD_ALIVE){break;} //End thread if killed by main.
	}
	return Data;
}

/*
	Continuously sends write requests.
*/
ThreadData *WriterThread(ThreadData *Data)
{
	Data->Writer = TRUE;
	while(TRUE)
	{
		#ifdef _WIN32
			Data->FT_LastFunction = FT_WritePipe;
            Data->Status = FT_WritePipe(Handle, 0x02 + Data->Channel,
        #else
			Data->FT_LastFunction = FT_WritePipeAsync;
            Data->Status = FT_WritePipeAsync(Handle, Data->Channel, //Linux uses FIFO ID.
        #endif //_WIN32
                                                Data->Buffer, REQUEST_SIZE,
                                                &Data->BytesTransferred, &Data->Overlap);
		if((Data->Status != FT_OK) && (Data->Status != FT_IO_PENDING))
		{Data->Dead = THREAD_DIED; PrintThreadStatus(Data); break;} //Print status and exit while loop.
		Data->FT_LastFunction = FT_GetOverlappedResult;
		Data->BytesTransferred = 0;
		Data->Status = FT_GetOverlappedResult(Handle, &Data->Overlap, &Data->BytesTransferred, TRUE);
		if(!HandleThreadIoCompletion(Data))
		{break;} //Print status and exit while loop.
		Data->BytesTransferred = 0;
		//Successfully wrote data. Continue.
		++Data->Iteration;
		if(Data->Dead != THREAD_ALIVE){break;} //End thread if killed by main.
	}
	return Data;
}

int main(int argc, char *argv[])
{
	(void)argc; (void)argv;
	srand(time(NULL)); //Initialize rand().
	FT_STATUS Status = FT_OK;
	DWORD DeviceCount = 0;
	ThreadData *Threads;
	int ThreadCount = THREAD_COUNT * CHANNEL_COUNT * 2; //*2 from read AND write thread per channel.
	InitializeCriticalSection(&PrintMutex);
	printf("Channel Count = %i\n", CHANNEL_COUNT);
	printf("Thread Count = %i\n", ThreadCount);
	printf("REQUEST_SIZE = %i\n", REQUEST_SIZE);
	Status = FT_CreateDeviceInfoList(&DeviceCount);
	if(Status != FT_OK){printf("ERROR: FT_CreateDeviceInfoList = %i\n", Status); return 0;}
	if(!DeviceCount){printf("ERROR: No devices detected.\n"); return 0;}
	printf("Detected %i devices!\n", DeviceCount);

	#ifndef _WIN32
		for(int i = 0; i < CHANNEL_COUNT; ++i)
		{
			FT_TRANSFER_CONF TransferConfig;
			memset(&TransferConfig, 0, sizeof(FT_TRANSFER_CONF));
			TransferConfig.wStructSize = sizeof(FT_TRANSFER_CONF);
			TransferConfig.pipe[FT_PIPE_DIR_IN].bURBCount = THREAD_COUNT;
			TransferConfig.pipe[FT_PIPE_DIR_OUT].bURBCount = THREAD_COUNT;
			TransferConfig.pipe[FT_PIPE_DIR_IN].dwStreamingSize = REQUEST_SIZE;
			TransferConfig.pipe[FT_PIPE_DIR_OUT].dwStreamingSize = REQUEST_SIZE;
			Status = FT_SetTransferParams(&TransferConfig, i);
			if(Status != FT_OK){printf("ERROR: FT_SetTransferParams = %i\n", Status); return 0;}
		}
	#endif //_WIN32

	Status = FT_Create(0, FT_OPEN_BY_INDEX, &Handle);
	#ifndef _WIN32
		for(int i = 0; i < CHANNEL_COUNT; ++i)
		{
			FT_TRANSFER_CONF TransferConfig;
			memset(&TransferConfig, 0, sizeof(FT_TRANSFER_CONF));
			TransferConfig.wStructSize = sizeof(FT_TRANSFER_CONF);
			Status = FT_GetTransferParams(&TransferConfig, i);
			if(Status != FT_OK){printf("ERROR: FT_GetTransferParams = %i\n", Status); return 0;}
			printf("Channel %i IN Max ThreadCount = %i\n", i+1, TransferConfig.pipe[FT_PIPE_DIR_IN].bURBCount);
			printf("Channel %i OUT Max Thread Count = %i\n", i+1, TransferConfig.pipe[FT_PIPE_DIR_OUT].bURBCount);
		}
	#endif //_WIN32
	if(Status != FT_OK){printf("ERROR: FT_Create = %i\n", Status); return 0;}
	if(DISABLE_TIMEOUTS)
	{
		for(UCHAR i = 0x02; i <= 0x05; ++i)
		{
			Status = FT_SetPipeTimeout(Handle,i,0); //Disable timeouts.
			if(Status != FT_OK){printf("ERROR[0x%02x]: FT_SetPipeTimeout = %i\n", i, Status); return 0;}
			Status = FT_SetPipeTimeout(Handle,i | 0x80,0); //Disable timeouts.
			if(Status != FT_OK){printf("ERROR[0x%02x]: FT_SetPipeTimeout = %i\n", i | 0x80, Status); return 0;}
		}
	}

	Threads = malloc(sizeof(ThreadData) * (ThreadCount + 1)); //The +1 is for the PrintProgressThread.
	if(!Threads){printf("ERROR: Failed to allocate memory for threads!\n"); return 0;}
	printf("Generating data for threads...\n");
	for(ULONG i = 0; i < (ULONG)ThreadCount; ++i) //Initialize thread data!
	{
		Threads[i].ThreadID = (DWORD)i;
		Threads[i].ThreadNumber = (ULONG)i;
		Threads[i].Channel = (UCHAR)((i/2) % CHANNEL_COUNT); //Threads split into channels.
		Threads[i].Writer = (i % 2) ? TRUE : FALSE;
		Threads[i].Dead = THREAD_ALIVE; //Make sure main thread thinks thread is alive.
		Threads[i].Iteration = 0;
		Threads[i].Status = FT_OK;
		Threads[i].BytesTransferred = 0;
		Threads[i].FT_LastFunction = NULL;
		Threads[i].ThreadArray = Threads; //Give each thread reference to the main thread array.
		if(RANDOM_DATA)
		{
			for(int j = 0; j < REQUEST_SIZE; ++j)
			{
				Threads[i].Buffer[j] = (UCHAR)(rand() % 0x00FF); //Each byte is random value from 0x00-0xFF.
			}
		}
		//(ULONG)*((ULONG *)(&Threads[i].Buffer[0])) = i; //First ULONG bytes hold thread number.
		memcpy(&Threads[i].Buffer[0], &i, sizeof(i)); //^Linux complains about above, have to do it this way.
		//^Only relevant for print/writer threads as they don't overwrite the buffer they're sending.
		//^Irrelevant for reader threads as they overwrite the buffer with incoming data.
		Status = FT_InitializeOverlapped(Handle, &Threads[i].Overlap);
		if(Status != FT_OK){printf("ERROR: FT_InitializeOverlapped = %i\n", Status); return 0;}
	}

	//Initialize only necessary thread data for PrintProgressThread.
	Threads[ThreadCount].ThreadNumber = ThreadCount;
	Threads[ThreadCount].Dead = THREAD_ALIVE;
	Threads[ThreadCount].ThreadArray = Threads;
	//Create PrintProgressThread.
	#ifdef _WIN32
		Threads[ThreadCount].ThreadHandle = CreateThread(NULL, 0, (PVOID)(PrintProgressThread), &Threads[ThreadCount], 0, &Threads[ThreadCount].ThreadID);
	#else
		Threads[ThreadCount].ThreadHandle = (HANDLE) malloc(sizeof(pthread_t));
		if(Threads[ThreadCount].ThreadHandle)
		{
			if(pthread_create(Threads[ThreadCount].ThreadHandle, NULL, (PVOID)(PrintProgressThread), &Threads[ThreadCount]))
			{free(Threads[ThreadCount].ThreadHandle); Threads[ThreadCount].ThreadHandle = NULL;}
		}
		if(!Threads[ThreadCount].ThreadHandle)
		{
			printf("ERROR: Failed to make print thread!\n");
			return 0;
		}
	#endif //_WIN32

	printf("Making %i read/write threads...\n", ThreadCount);
	for(int i = 0; i < ThreadCount; ++i) //Make threads.
	{
		//Odd threads are writers. Even threads are readers.
		#ifdef _WIN32
			Threads[i].ThreadHandle = CreateThread(NULL, 0, (PVOID)((i % 2) ? WriterThread : ReaderThread), &Threads[i], 0, &Threads[i].ThreadID);
		#else
			Threads[i].ThreadHandle = (HANDLE) malloc(sizeof(pthread_t));
			if(Threads[i].ThreadHandle)
			{
				if(pthread_create(Threads[i].ThreadHandle, NULL, (PVOID)((i % 2) ? WriterThread : ReaderThread), &Threads[i]))
				{free(Threads[i].ThreadHandle); Threads[i].ThreadHandle = NULL;}
			}
			if(!Threads[i].ThreadHandle)
			{
				printf("ERROR: Failed to make thread %i!\n", i);
				return 0;
			}
		#endif //_WIN32
	}
	EnterCriticalSection(&PrintMutex);
	printf("Press ENTER to finish.\n");
	LeaveCriticalSection(&PrintMutex);
	getchar();

	/* Shutdown sequence:
	 * 1. Signal all threads to stop.
	 * 2. Abort OUT pipes  â†’ unblocks writers in FT_GetOverlappedResult/sem_wait.
	 * 3. Abort IN  pipes  â†’ unblocks readers in FT_GetOverlappedResult/sem_wait.
	 * 4. Kill and join print thread.
	 * 5. Join all reader/writer threads (with 100 ms timeout + cancel fallback).
	 * Aborting OUT before joining writers is critical: without it, writers
	 * whose transfers stall (device FIFO full) block the join indefinitely. */

	//Signal all threads to stop.
	ProgramStopping = 1;
	for(int i = 0; i < ThreadCount; ++i)
		if(Threads[i].Dead == THREAD_ALIVE){Threads[i].Dead = THREAD_KILLED;}

	//Abort OUT pipes first so writer threads unblock.
	for(UCHAR i = 0x02; i <= (UCHAR)(0x02 + CHANNEL_COUNT - 1); ++i)
	{
		Status = FT_AbortPipe(Handle, i);
		if(Status != FT_OK){printf("ERROR: FT_AbortPipe(0x%02x) = %i\n", i, Status);}
	}
	//Abort IN pipes so reader threads unblock.
	for(UCHAR i = 0x82; i <= (UCHAR)(0x82 + CHANNEL_COUNT - 1); ++i)
	{
		Status = FT_AbortPipe(Handle, i);
		if(Status != FT_OK){printf("ERROR: FT_AbortPipe(0x%02x) = %i\n", i, Status);}
	}

	//End PrintProgressThread.
	Threads[ThreadCount].Dead = THREAD_KILLED;
	#ifdef _WIN32
        WaitForSingleObject(Threads[ThreadCount].ThreadHandle, INFINITE);
        CloseHandle(Threads[ThreadCount].ThreadHandle);
    #else
		JoinThreadHandle(&Threads[ThreadCount].ThreadHandle);
    #endif //_WIN32

	EnterCriticalSection(&PrintMutex);
	printf("ENDING PROGRAM... (Please wait a couple seconds for output if your thread count & request size are large)\n");
	LeaveCriticalSection(&PrintMutex);

	//Join all reader/writer threads.
	for(int i = 0; i < ThreadCount; ++i)
	{
		#ifdef _WIN32
            WaitForSingleObject(Threads[i].ThreadHandle, INFINITE);
            CloseHandle(Threads[i].ThreadHandle);
        #else
			JoinThreadHandle(&Threads[i].ThreadHandle);
        #endif //_WIN32
	}

	for(int i = 0; i < ThreadCount; ++i) //Release overlaps initialized so far.
	{
		Status = FT_ReleaseOverlapped(Handle, &Threads[i].Overlap);
		if(Status != FT_OK){printf("ERROR: FT_ReleaseOverlapped = %i\n", Status); return 0;}
	}
	Status = FT_Close(Handle);
	if(Status != FT_OK){printf("ERROR: FT_Close = %i\n", Status); return 0;}
	free(Threads); //Free thread data.
	DeleteCriticalSection(&PrintMutex);
	printf("---| PROGRAM SUCCESSFULLY COMPLETED |---\n");
	return 0;
}

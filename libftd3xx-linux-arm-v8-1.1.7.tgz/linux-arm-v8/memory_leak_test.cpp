#include <atomic>
#include <chrono>
#include <condition_variable>
#include <cstdint>
#include <cstring>
#include <iostream>
#include <mutex>
#include <queue>
#include <thread>
#include <vector>

#ifdef _WIN32
#include "FTD3XX.h"
#else
#include "ftd3xx.h"
#include "Types.h"
#endif

namespace {

constexpr int kNumInflight = 8;
constexpr size_t kDefaultBufferSize = 128 * 1024;
constexpr size_t kMaxValidPacketBytes = 20 * 1024 * 1024;
constexpr int kTestDurationSeconds = 10;

void triggerError(const char *msg, int errCode)
{
    std::cerr << "Error: " << msg << " (" << errCode << ")" << std::endl;
}

struct DataPacket {
    unsigned char pipeID;
    std::vector<uint8_t> data;
};

class DataReceiveManager {
public:
    std::atomic<bool> dataReceiveRunning{true};
    std::atomic<bool> dataReceiveEnabled{true};
    std::atomic<size_t> dataReceiveBufferSize{kDefaultBufferSize};
    unsigned char dataReceivePipeID = 0x82;

    std::mutex dataQueueMutex;
    std::queue<DataPacket> dataQueue;
    std::condition_variable dataQueueCondition;

    void dataReceiveThreadFunc(FT_HANDLE ftHandle, const std::atomic<bool> &initialized);
};

void releaseOverlappedRange(FT_HANDLE ftHandle,
                            std::vector<OVERLAPPED> *ovArray,
                            size_t count)
{
    for (size_t i = 0; i < count; ++i)
        (void)FT_ReleaseOverlapped(ftHandle, &(*ovArray)[i]);
}

} // namespace

void DataReceiveManager::dataReceiveThreadFunc(FT_HANDLE ftHandle,
                                               const std::atomic<bool> &initialized)
{
    while (dataReceiveRunning.load()) {
        if (dataReceiveEnabled.load() && initialized.load())
            break;
        std::this_thread::sleep_for(std::chrono::milliseconds(1));
    }
    if (!dataReceiveRunning.load())
        return;

    const int numInflight = kNumInflight;
    const size_t bufferSize = dataReceiveBufferSize.load();

    FT_STATUS streamStatus = FT_SetStreamPipe(ftHandle, 0, 0, dataReceivePipeID,
                                              static_cast<ULONG>(bufferSize));
    const bool streamEnabled = FT_SUCCESS(streamStatus);
    if (!streamEnabled) {
        std::cerr << "[DataReceive] FT_SetStreamPipe failed (status=" << streamStatus
                  << "), continuing without streaming mode" << std::endl;
    }

    std::vector<std::vector<uint8_t>> buffers(numInflight);
    std::vector<OVERLAPPED> ovArray(numInflight);
    std::vector<ULONG> bytesReadArray(numInflight, 0);
    std::vector<uint8_t> inFlight(numInflight, 0);

    for (int i = 0; i < numInflight; ++i) {
        buffers[i].resize(bufferSize);
        memset(&ovArray[i], 0, sizeof(OVERLAPPED));

        FT_STATUS initStatus = FT_InitializeOverlapped(ftHandle, &ovArray[i]);
        if (!FT_SUCCESS(initStatus)) {
            std::cerr << "[DataReceive] FT_InitializeOverlapped failed for slot " << i
                      << " (status=" << initStatus << ")" << std::endl;
            releaseOverlappedRange(ftHandle, &ovArray, static_cast<size_t>(i));
            if (streamEnabled)
                (void)FT_ClearStreamPipe(ftHandle, 0, 0, dataReceivePipeID);
            return;
        }
    }

#ifndef _WIN32
    if (dataReceivePipeID < 0x82 || dataReceivePipeID > 0x85) {
        std::cerr << "[DataReceive] Invalid read pipe ID 0x" << std::hex
                  << static_cast<unsigned>(dataReceivePipeID) << std::dec << std::endl;
        releaseOverlappedRange(ftHandle, &ovArray, ovArray.size());
        if (streamEnabled)
            (void)FT_ClearStreamPipe(ftHandle, 0, 0, dataReceivePipeID);
        return;
    }
    const UCHAR fifoIndex = static_cast<UCHAR>(dataReceivePipeID - 0x82);
#endif

    auto issueRead = [&](int i) -> bool {
        bytesReadArray[i] = 0;
#ifdef _WIN32
        FT_STATUS s = FT_ReadPipe(ftHandle, dataReceivePipeID,
                                  buffers[i].data(),
                                  static_cast<ULONG>(bufferSize),
                                  &bytesReadArray[i],
                                  &ovArray[i]);
#else
        FT_STATUS s = FT_ReadPipeAsync(ftHandle, fifoIndex,
                                       buffers[i].data(),
                                       static_cast<ULONG>(bufferSize),
                                       &bytesReadArray[i],
                                       &ovArray[i]);
#endif
        if (s == FT_IO_PENDING) {
            inFlight[i] = 1;
            return false;
        }
        if (FT_SUCCESS(s) && bytesReadArray[i] > 0) {
            inFlight[i] = 0;
            return true;
        }
        inFlight[i] = 0;
        return false;
    };

    auto enqueue = [&](int i, ULONG bytes) {
        if (bytes == 0 || bytes > kMaxValidPacketBytes)
            return;

        DataPacket packet;
        packet.pipeID = dataReceivePipeID;
        buffers[i].resize(bytes);
        packet.data = std::move(buffers[i]);
        {
            std::lock_guard<std::mutex> lock(dataQueueMutex);
            dataQueue.push(std::move(packet));
        }
        dataQueueCondition.notify_one();
        buffers[i].resize(bufferSize);
    };

    for (int i = 0; i < numInflight; ++i) {
        if (issueRead(i)) {
            enqueue(i, bytesReadArray[i]);
            (void)issueRead(i);
        }
    }

    int head = 0;
    while (dataReceiveRunning.load()) {
        if (!dataReceiveEnabled.load() || !initialized.load()) {
            std::this_thread::sleep_for(std::chrono::milliseconds(1));
            continue;
        }

        if (!inFlight[head]) {
            if (issueRead(head)) {
                enqueue(head, bytesReadArray[head]);
                (void)issueRead(head);
            }
            if (!inFlight[head]) {
                head = (head + 1) % numInflight;
                std::this_thread::sleep_for(std::chrono::milliseconds(1));
                continue;
            }
        }

        ULONG bytesTransferred = 0;
        FT_STATUS result = FT_GetOverlappedResult(ftHandle, &ovArray[head],
                                                  &bytesTransferred, TRUE);
        inFlight[head] = 0;

        if (FT_SUCCESS(result)) {
            enqueue(head, bytesTransferred);
        } else if (result == FT_OPERATION_ABORTED) {
            break;
        } else if (result == FT_DEVICE_NOT_FOUND || result == FT_DEVICE_NOT_OPENED) {
            triggerError("Device disconnected or not found", static_cast<int>(result));
            dataReceiveEnabled = false;
            break;
        }

        if (issueRead(head)) {
            enqueue(head, bytesReadArray[head]);
            (void)issueRead(head);
        }
        head = (head + 1) % numInflight;
    }

    (void)FT_AbortPipe(ftHandle, dataReceivePipeID);
    for (int i = 0; i < numInflight; ++i) {
        if (inFlight[i]) {
            ULONG dummy = 0;
            (void)FT_GetOverlappedResult(ftHandle, &ovArray[i], &dummy, TRUE);
        }
        (void)FT_ReleaseOverlapped(ftHandle, &ovArray[i]);
    }
    if (streamEnabled)
        (void)FT_ClearStreamPipe(ftHandle, 0, 0, dataReceivePipeID);
}

void processingThreadFunc(DataReceiveManager *manager)
{
    for (;;) {
        std::unique_lock<std::mutex> lock(manager->dataQueueMutex);
        manager->dataQueueCondition.wait_for(
            lock,
            std::chrono::milliseconds(10),
            [&] {
                return !manager->dataQueue.empty() ||
                       !manager->dataReceiveRunning.load();
            });

        while (!manager->dataQueue.empty()) {
            DataPacket packet = std::move(manager->dataQueue.front());
            manager->dataQueue.pop();
            (void)packet;
        }

        if (!manager->dataReceiveRunning.load() && manager->dataQueue.empty())
            break;
    }
}

int main()
{
    FT_HANDLE handle = nullptr;
    FT_STATUS status = FT_Create((PVOID)(uintptr_t)0, FT_OPEN_BY_INDEX, &handle);
    if (!FT_SUCCESS(status)) {
        std::cerr << "Failed to open FTDI device. Ensure it's connected. Status: "
                  << status << std::endl;
        return 1;
    }

    std::cout << "Device opened successfully. Starting tests..." << std::endl;

    DataReceiveManager manager;
    std::atomic<bool> initialized{true};

    std::thread procThread(processingThreadFunc, &manager);
    std::thread rxThread(&DataReceiveManager::dataReceiveThreadFunc,
                         &manager, handle, std::ref(initialized));

    std::cout << "Running memory leak test for " << kTestDurationSeconds
              << " seconds..." << std::endl;
    for (int i = 0; i < kTestDurationSeconds; ++i) {
        std::cout << "." << std::flush;
        std::this_thread::sleep_for(std::chrono::seconds(1));
    }
    std::cout << std::endl;

    std::cout << "Shutting down..." << std::endl;
    manager.dataReceiveRunning = false;
    manager.dataReceiveEnabled = false;
    manager.dataQueueCondition.notify_all();

    (void)FT_AbortPipe(handle, manager.dataReceivePipeID);

    rxThread.join();
    procThread.join();

    FT_Close(handle);
    std::cout << "Test completed without hangs. To check for memory leaks, run this binary using valgrind."
              << std::endl;
    return 0;
}

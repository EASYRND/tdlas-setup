/*
 * File: ChipConfigTool.c
 * Description:
 *     Demonstration utility for reading, displaying, and modifying the
 *     configuration of FTDI FT600/FT601 SuperSpeed bridge devices using
 *     the FTDI D3XX driver API.
 *
 *     This program retrieves the chip's current configuration from flash/
 *     ROM, prints all relevant descriptors (device, string, power, FIFO,
 *     GPIO, MSIO, and optional features), then modifies several parameters
 *     such as FIFO mode and channel configuration. After writing new values
 *     to the device, it reboots the FT60x and reads the configuration again
 *     to verify changes.  
 *
 * Functional Overview:
 *     • FT_Create()                   — Open FT60x device  
 *     • FT_GetChipConfiguration()     — Read configuration from flash  
 *     • ShowConfiguration()           — Decode & print all descriptor fields  
 *     • FT_SetChipConfiguration()     — Write updated configuration  
 *     • Device automatic reboot       — Required after writing config  
 *     • Re-open device and re-read    — Verify applied configuration  
 *
 * What This Tool Demonstrates:
 *     • How to switch between:
 *           - 245 FIFO Mode
 *           - 600 FIFO Mode
 *     • How to change:
 *           - FIFO Clock
 *           - Channel Config (1, 2, or 4 channels)
 *           - Optional Feature Flags (Cancel-on-Underrun, Notifications, etc.)
 *     • How to inspect:
 *           - USB Device Descriptors
 *           - String descriptors (Manufacturer, Product, Serial)
 *           - Battery charging configuration
 *           - GPIO/MSIO configuration
 *           - Flash/ROM presence, validity, checksum, and GPIO boot state
 *
 * Notes:
 *     • Writing configuration triggers a full device reboot—software must pause
 *       several seconds before re-opening the device.
 *     • This tool is meant for development, evaluation, and debugging of FT60x
 *       configuration behavior. It is not intended to run during normal data
 *       streaming operations.
 *     • Ensure only one application accesses the FT60x device at a time.
 *
 * Requirements:
 *     • FTDI D3XX driver installed
 *     • FT600/FT601 device connected
 *     • Headers: ftd3xx.h
 *
 * Author: <FTDI Chip>
 * Created: <2025>
 */

#include "ftd3xx.h"
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define USE_245_MODE 1
#define LOOPBACK_MODE 1

#ifndef TRUE
#define TRUE 1
#endif
#ifndef FALSE
#define FALSE 0
#endif

#define NUM_CPUCLOCK 4
#define NUM_FIFOCLOCK 4
#define NUM_FIFOMODE 2
#define NUM_BCCONFIGURATION 4
#define NUM_CHANNELCONFIG 5

const char* g_szFIFOClock[NUM_FIFOCLOCK] =
{
    "100 MHz",
    "66 MHz",
    "50 MHz",
    "40 MHz",
};

const char* g_szFIFOMode[NUM_FIFOMODE] =
{
    "245 Mode",
    "600 Mode",
};

const char* g_szBCDConfiguration[NUM_BCCONFIGURATION] =
{
    "00 (GPIO1=0, GPIO2=0)",
    "01 (GPIO1=0, GPIO2=1)",
    "10 (GPIO1=1, GPIO2=0)",
    "11 (GPIO1=1, GPIO2=1)",
};

const char* g_szChannelConfig[NUM_CHANNELCONFIG] =
{
    "4 Channels",
    "2 Channels",
    "1 Channel",
    "1 OUT Pipe",
    "1 IN Pipe",
};

#define CMD_LOG(...) printf(__VA_ARGS__)

void ShowConfiguration(const void *a_pvConfigurationData, BOOL a_bRead) {
  const PFT_60XCONFIGURATION a_pConfigurationData =
      (PFT_60XCONFIGURATION)a_pvConfigurationData;

  CMD_LOG("\n");
  CMD_LOG("\tDevice Descriptor\n");
  CMD_LOG("\tVendorID             : 0x%04X\n", a_pConfigurationData->VendorID);
  CMD_LOG("\tProductID            : 0x%04X\n", a_pConfigurationData->ProductID);

  char ucTemp[128] = {0};
  unsigned char *pOffset = NULL;
  int remaining = 128;
  CMD_LOG("\n");
  CMD_LOG("\tString Descriptor\n");
  pOffset = (unsigned char *)&a_pConfigurationData->StringDescriptors[0];

  memset(ucTemp, 0, sizeof(ucTemp));
  if (remaining >= 2 && pOffset[0] >= 2 && pOffset[0] <= remaining) {
    if (pOffset[0] > 2) {
      for (int i = 0; i < (pOffset[0] - 2); i += 2) {
        ucTemp[i / 2] = pOffset[i + 2];
      }
    }
    remaining -= pOffset[0];
    pOffset += pOffset[0];
  }
  CMD_LOG("\tManufacturer             : %s\n", ucTemp);

  memset(ucTemp, 0, sizeof(ucTemp));
  if (remaining >= 2 && pOffset[0] >= 2 && pOffset[0] <= remaining) {
    if (pOffset[0] > 2) {
      for (int i = 0; i < (pOffset[0] - 2); i += 2) {
        ucTemp[i / 2] = pOffset[i + 2];
      }
    }
    remaining -= pOffset[0];
    pOffset += pOffset[0];
  }
  CMD_LOG("\tProduct Description      : %s\n", ucTemp);

  memset(ucTemp, 0, sizeof(ucTemp));
  if (remaining >= 2 && pOffset[0] >= 2 && pOffset[0] <= remaining) {
    if (pOffset[0] > 2) {
      for (int i = 0; i < (pOffset[0] - 2); i += 2) {
        ucTemp[i / 2] = pOffset[i + 2];
      }
    }
    remaining -= pOffset[0];
    pOffset += pOffset[0];
  }
  CMD_LOG("\tSerial Number            : %s\n", ucTemp);

  CMD_LOG("\n");
  CMD_LOG("\tConfiguration Descriptor\n");
  CMD_LOG("\tbInterval                : %d\n",
          a_pConfigurationData->bInterval);
  CMD_LOG("\tPowerAttributes          : %s %s\n",
          FT_IS_BUS_POWERED(a_pConfigurationData->PowerAttributes)
              ? "Bus-powered "
              : "Self-powered ",
          FT_IS_REMOTE_WAKEUP_ENABLED(a_pConfigurationData->PowerAttributes)
              ? "Remote wakeup "
              : "");
  CMD_LOG("\tPowerConsumption         : %d\n",
          a_pConfigurationData->PowerConsumption);

  CMD_LOG("\n");
  CMD_LOG("\tData Transfer\n");
  CMD_LOG("\tFIFOClock                : %s\n",
          g_szFIFOClock[a_pConfigurationData->FIFOClock]);
  CMD_LOG("\tFIFOMode                 : %s\n",
          g_szFIFOMode[a_pConfigurationData->FIFOMode]);
  CMD_LOG("\tChannelConfig            : %s\n",
          g_szChannelConfig[a_pConfigurationData->ChannelConfig]);

  CMD_LOG("\n");
  CMD_LOG("\tOptional Features\n");
  CMD_LOG("\tDisableCancelOnUnderrun  : %d\n",
          (a_pConfigurationData->OptionalFeatureSupport &
           CONFIGURATION_OPTIONAL_FEATURE_DISABLECANCELSESSIONUNDERRUN) >>
              1);
  CMD_LOG("\tNotificationEnabled      : %d (%d %d %d %d)\n",
          (a_pConfigurationData->OptionalFeatureSupport &
           CONFIGURATION_OPTIONAL_FEATURE_ENABLENOTIFICATIONMESSAGE_INCHALL) >>
              2,
          (a_pConfigurationData->OptionalFeatureSupport &
           CONFIGURATION_OPTIONAL_FEATURE_ENABLENOTIFICATIONMESSAGE_INCH1)
              ? 1
              : 0,
          (a_pConfigurationData->OptionalFeatureSupport &
           CONFIGURATION_OPTIONAL_FEATURE_ENABLENOTIFICATIONMESSAGE_INCH2)
              ? 1
              : 0,
          (a_pConfigurationData->OptionalFeatureSupport &
           CONFIGURATION_OPTIONAL_FEATURE_ENABLENOTIFICATIONMESSAGE_INCH3)
              ? 1
              : 0,
          (a_pConfigurationData->OptionalFeatureSupport &
           CONFIGURATION_OPTIONAL_FEATURE_ENABLENOTIFICATIONMESSAGE_INCH4)
              ? 1
              : 0);
  CMD_LOG("\tDisableUnderrun          : %d (%d %d %d %d)\n",
          (a_pConfigurationData->OptionalFeatureSupport &
           CONFIGURATION_OPTIONAL_FEATURE_DISABLEUNDERRUN_INCHALL) >>
              6,
          (a_pConfigurationData->OptionalFeatureSupport &
           CONFIGURATION_OPTIONAL_FEATURE_DISABLEUNDERRUN_INCH1)
              ? 1
              : 0,
          (a_pConfigurationData->OptionalFeatureSupport &
           CONFIGURATION_OPTIONAL_FEATURE_DISABLEUNDERRUN_INCH2)
              ? 1
              : 0,
          (a_pConfigurationData->OptionalFeatureSupport &
           CONFIGURATION_OPTIONAL_FEATURE_DISABLEUNDERRUN_INCH3)
              ? 1
              : 0,
          (a_pConfigurationData->OptionalFeatureSupport &
           CONFIGURATION_OPTIONAL_FEATURE_DISABLEUNDERRUN_INCH4)
              ? 1
              : 0);
  CMD_LOG("\tBatteryChargingEnabled   : %d\n",
          (a_pConfigurationData->OptionalFeatureSupport &
           CONFIGURATION_OPTIONAL_FEATURE_ENABLEBATTERYCHARGING) ? 1 : 0);
  CMD_LOG("\tBCGPIOPinConfig          : 0x%02X\n",
          a_pConfigurationData->BatteryChargingGPIOConfig);

  if (a_bRead) {
    CMD_LOG("\tFlashEEPROMDetection     : 0x%02X\n\n",
            a_pConfigurationData->FlashEEPROMDetection);
    CMD_LOG("\t\tMemory Type            : %s\n",
            a_pConfigurationData->FlashEEPROMDetection &
                    (1 << CONFIGURATION_FLASH_ROM_BIT_ROM)
                ? "ROM"
                : "Flash");
    CMD_LOG("\t\tMemory Detected        : %s\n",
            a_pConfigurationData->FlashEEPROMDetection &
                    (1 << CONFIGURATION_FLASH_ROM_BIT_MEMORY_NOTEXIST)
                ? "Not Exists"
                : "Exists");
    CMD_LOG("\t\tCustom Config Validity : %s\n",
            a_pConfigurationData->FlashEEPROMDetection &
                    (1 << CONFIGURATION_FLASH_ROM_BIT_CUSTOMDATA_INVALID)
                ? "Invalid"
                : "Valid");
    CMD_LOG("\t\tCustom Config Checksum : %s\n",
            a_pConfigurationData->FlashEEPROMDetection &
                    (1 << CONFIGURATION_FLASH_ROM_BIT_CUSTOMDATACHKSUM_INVALID)
                ? "Invalid"
                : "Valid");
    CMD_LOG("\t\tGPIO Input             : %s\n",
            a_pConfigurationData->FlashEEPROMDetection &
                    (1 << CONFIGURATION_FLASH_ROM_BIT_GPIO_INPUT)
                ? "Used"
                : "Ignore");
    CMD_LOG("\t\tConfig Used            : %s\n",
            a_pConfigurationData->FlashEEPROMDetection &
                    (1 << CONFIGURATION_FLASH_ROM_BIT_CUSTOM)
                ? "CUSTOM"
                : "DEFAULT");
    if (a_pConfigurationData->FlashEEPROMDetection &
        (1 << CONFIGURATION_FLASH_ROM_BIT_GPIO_INPUT)) {
      CMD_LOG("\t\tGPIO 0                 : %s\n",
              a_pConfigurationData->FlashEEPROMDetection &
                      (1 << CONFIGURATION_FLASH_ROM_BIT_GPIO_0)
                  ? "High"
                  : "Low");
      CMD_LOG("\t\tGPIO 1                 : %s\n",
              a_pConfigurationData->FlashEEPROMDetection &
                      (1 << CONFIGURATION_FLASH_ROM_BIT_GPIO_1)
                  ? "High"
                  : "Low");
    }
  }

  CMD_LOG("\n");
  CMD_LOG("\tMSIO and GPIO configuration\n");
  CMD_LOG("\tMSIOControl                : 0x%08X\n",
          a_pConfigurationData->MSIO_Control);
  CMD_LOG("\tGPIOControl                : 0x%08X\n",
          a_pConfigurationData->GPIO_Control);

  CMD_LOG("\n");
}

///////////////////////////////////////////////////////////////////////////////////
// Demonstrates modifying current setting of chip configuration
// FT_Create              Open a device
// FT_GetChipConfiguration      Read configuration from chip's flash memory
// FT_SetChipConfiguration      Write configuration to chip's flash memory
//                      FTDI_CFG - query and set chip configuration
// FT_Close               Close device handle
///////////////////////////////////////////////////////////////////////////////////
BOOL ModifyChipConfigurationTest()
{
    FT_STATUS ftStatus = FT_OK;
    FT_HANDLE ftHandle = NULL;
    FT_60XCONFIGURATION oConfigurationData = {0};
    UCHAR uOriginalFIFOMode = 0;
    UCHAR uOriginalChannelConfig = 0;

  //
  // 1. Open device and read initial configuration
  //
  ftStatus = FT_Create(0, FT_OPEN_BY_INDEX, &ftHandle);
  if (FT_FAILED(ftStatus)) {
    printf("Failed to open device (Status: 0x%X)\n", ftStatus);
    return FALSE;
  }

  ftStatus = FT_GetChipConfiguration(ftHandle, &oConfigurationData);
  if (FT_FAILED(ftStatus)) {
    printf("Failed to get chip configuration (Status: 0x%X)\n", ftStatus);
    FT_Close(ftHandle);
    return FALSE;
  }

  uOriginalFIFOMode = oConfigurationData.FIFOMode;
  uOriginalChannelConfig = oConfigurationData.ChannelConfig;
  printf("\nInitial Configuration:\n");
  ShowConfiguration(&oConfigurationData, TRUE);

  //
  // 2. Switch to the other mode
  //
  if (uOriginalFIFOMode == CONFIGURATION_FIFO_MODE_245) {
    printf("Changing mode from 245 to 600...\n");
    oConfigurationData.FIFOMode = CONFIGURATION_FIFO_MODE_600;
    oConfigurationData.ChannelConfig = CONFIGURATION_CHANNEL_CONFIG_4;
  } else {
    printf("Changing mode from 600 to 245...\n");
    oConfigurationData.FIFOMode = CONFIGURATION_FIFO_MODE_245;
    oConfigurationData.ChannelConfig = CONFIGURATION_CHANNEL_CONFIG_1;
  }

  ftStatus = FT_SetChipConfiguration(ftHandle, &oConfigurationData);
  if (FT_FAILED(ftStatus)) {
    printf("Failed to set chip configuration (Status: 0x%X)\n", ftStatus);
    FT_Close(ftHandle);
    return FALSE;
  }

  FT_Close(ftHandle);
  printf("Device rebooting. Waiting 5 seconds...\n");
  sleep(5);

  //
  // 3. Verify intermediate mode
  //
  ftStatus = FT_Create(0, FT_OPEN_BY_INDEX, &ftHandle);
  if (FT_FAILED(ftStatus)) {
    printf("Failed to open device after reboot (Status: 0x%X)\n", ftStatus);
    return FALSE;
  }

  ftStatus = FT_GetChipConfiguration(ftHandle, &oConfigurationData);
  if (FT_FAILED(ftStatus)) {
    printf("Failed to get chip configuration after reboot (Status: 0x%X)\n",
           ftStatus);
    FT_Close(ftHandle);
    return FALSE;
  }

  printf("\nIntermediate Configuration:\n");
  ShowConfiguration(&oConfigurationData, TRUE);

  if (oConfigurationData.FIFOMode == uOriginalFIFOMode) {
    printf("Error: Mode did not change!\n");
    FT_Close(ftHandle);
    return FALSE;
  }

  //
  // 4. Switch back to original mode and original channel configuration
  //
  printf("Changing mode back to original (%s) and original channel config "
         "(%s)...\n",
         uOriginalFIFOMode == CONFIGURATION_FIFO_MODE_245 ? "245" : "600",
         g_szChannelConfig[uOriginalChannelConfig]);

  oConfigurationData.FIFOMode = uOriginalFIFOMode;
  oConfigurationData.ChannelConfig = uOriginalChannelConfig;

  ftStatus = FT_SetChipConfiguration(ftHandle, &oConfigurationData);
  if (FT_FAILED(ftStatus)) {
    printf("Failed to revert chip configuration (Status: 0x%X)\n", ftStatus);
    FT_Close(ftHandle);
    return FALSE;
  }

  FT_Close(ftHandle);
  printf("Device rebooting. Waiting 5 seconds...\n");
  sleep(5);

  //
  // 5. Final verification
  //
  ftStatus = FT_Create(0, FT_OPEN_BY_INDEX, &ftHandle);
  if (FT_FAILED(ftStatus)) {
    printf("Failed to open device for final verification (Status: 0x%X)\n",
           ftStatus);
    return FALSE;
  }

  ftStatus = FT_GetChipConfiguration(ftHandle, &oConfigurationData);
  if (FT_FAILED(ftStatus)) {
    printf("Failed to get chip configuration for final verification (Status: "
           "0x%X)\n",
           ftStatus);
    FT_Close(ftHandle);
    return FALSE;
  }

  printf("\nFinal Configuration:\n");
  ShowConfiguration(&oConfigurationData, TRUE);

  if (oConfigurationData.FIFOMode != uOriginalFIFOMode ||
      oConfigurationData.ChannelConfig != uOriginalChannelConfig) {
    printf("Error: Mode or Channel Config did not revert correctly!\n");
    FT_Close(ftHandle);
    return FALSE;
  }

  printf("Round-trip mode switch successful!\n");
  FT_Close(ftHandle);
  return TRUE;
}

int main() {
  ModifyChipConfigurationTest();
  return 0;
}

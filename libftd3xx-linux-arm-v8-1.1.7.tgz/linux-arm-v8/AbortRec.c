#include <string.h>
#include <time.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include "ftd3xx.h"

#define DEFAULT_TIMEOUT_MS 5000

static void show_help(const char *bin)
{
	printf("Usage: %s <read length> [timeout_ms] [fifo_channel]\r\n", bin);
	printf("  read length : number of bytes to read\r\n");
	printf("  timeout_ms  : read timeout in milliseconds (default %d)\r\n", DEFAULT_TIMEOUT_MS);
	printf("  fifo_channel: 0-3 (default 0)\r\n");
	printf("  Only FT245 mode is supported in this demo\r\n");
}

int main(int argc, char *argv[])
{
	FT_HANDLE handle = NULL;
	FT_STATUS ftStatus = FT_OK;

	if (argc < 2 || argc > 4) {
		show_help(argv[0]);
		return 1;
	}
	uint32_t to_read = (uint32_t)atoi(argv[1]);
	if (to_read == 0) {
		show_help(argv[0]);
		return 1;
	}
	DWORD timeout_ms = DEFAULT_TIMEOUT_MS;
	if (argc >= 3)
		timeout_ms = (DWORD)atoi(argv[2]);
	int channel = 0;
	if (argc == 4) {
		channel = atoi(argv[3]);
		if (channel < 0 || channel > 3) {
			show_help(argv[0]);
			return 1;
		}
	}
	UCHAR fifo_id = (UCHAR)channel;
	UCHAR pipe_id = (UCHAR)(0x82 + channel);

	FT_Create(0, FT_OPEN_BY_INDEX, &handle);

	if (!handle) {
		printf("Failed to create device\r\n");
		return -1;
	}
	printf("Device created\r\n");
	ftStatus = FT_SetPipeTimeout(handle, pipe_id, timeout_ms);
	if (ftStatus != FT_OK)
		printf("FT_SetPipeTimeout failed (status=%d)\r\n", ftStatus);

	uint8_t *in_buf = (uint8_t *)malloc(to_read);
	if (!in_buf) {
		printf("Failed to allocate buffer\r\n");
		FT_Close(handle);
		return 1;
	}
	DWORD count;

	while(1)
	{
        ftStatus = FT_ReadPipeEx(handle, fifo_id, in_buf, to_read,
            &count, timeout_ms);
        if (FT_OK != ftStatus) {
            printf("Read failed (status=%d). FIFO may be empty.\r\n", ftStatus);
            goto _Exit;
        }
        printf("Read %d bytes\r\n", count);
		break;
	}

_Exit:
	free(in_buf);
	UCHAR ucDirection = (FT_GPIO_DIRECTION_OUT << FT_GPIO_0) ;
	UCHAR ucMask = (FT_GPIO_VALUE_HIGH << FT_GPIO_0);
	ftStatus = FT_EnableGPIO(handle, ucMask, ucDirection);
    if(ftStatus != FT_OK)
	{
		printf("FT_EnableGPIO is Failed...=%d\n",ftStatus);
		return 0;
	}
	ftStatus = FT_WriteGPIO(handle,ucMask, (FT_GPIO_VALUE_HIGH << FT_GPIO_0));
	    if(ftStatus != FT_OK)
	{
		printf("FT_WriteGPIO is Failed...=%d\n",ftStatus);
		return 0;
	}
	FT_AbortPipe(handle, pipe_id);	
	FT_WriteGPIO(handle,ucMask, (FT_GPIO_VALUE_LOW << FT_GPIO_0));

    FT_Close(handle);
	return 0;
}


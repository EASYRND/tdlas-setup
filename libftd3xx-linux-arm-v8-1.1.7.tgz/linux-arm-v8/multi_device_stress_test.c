#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>
#include <errno.h>
#include <pthread.h>
#include <time.h>

#ifdef _WIN32
#include "FTD3XX.h"
#else
#include "ftd3xx.h"
#endif

#define DEFAULT_TIMEOUT_MS 100
#define DEFAULT_IO_LEN 1024
#define DEFAULT_STREAM_SIZE 4096
#define MAX_TEST_DEVICES 16

typedef struct {
    DWORD timeout_ms;
    ULONG io_len;
    ULONG stream_size;
    int only_index;
    bool enable_stream;
    bool enable_params;
    bool parallel;
    int loops;
    int seconds;
    uint8_t fifo_mask;
    bool errors_only;
} test_options;

static const char *ft_status_to_string(FT_STATUS status)
{
    switch (status)
    {
    case FT_OK: return "FT_OK";
    case FT_INVALID_HANDLE: return "FT_INVALID_HANDLE";
    case FT_DEVICE_NOT_FOUND: return "FT_DEVICE_NOT_FOUND";
    case FT_DEVICE_NOT_OPENED: return "FT_DEVICE_NOT_OPENED";
    case FT_IO_ERROR: return "FT_IO_ERROR";
    case FT_INSUFFICIENT_RESOURCES: return "FT_INSUFFICIENT_RESOURCES";
    case FT_INVALID_PARAMETER: return "FT_INVALID_PARAMETER";
    case FT_TIMEOUT: return "FT_TIMEOUT";
    case FT_OPERATION_ABORTED: return "FT_OPERATION_ABORTED";
    case FT_BUSY: return "FT_BUSY";
    case FT_OTHER_ERROR: return "FT_OTHER_ERROR";
    default: return "FT_STATUS_UNKNOWN";
    }
}

static bool parse_ulong(const char *text, unsigned long *out)
{
    char *end = NULL;
    errno = 0;
    unsigned long value = strtoul(text, &end, 0);
    if (errno != 0 || end == text || (end && *end != '\0')) {
        return false;
    }
    *out = value;
    return true;
}

static void print_usage(const char *argv0)
{
    printf("Usage: %s [options]\n", argv0);
    printf("Options:\n");
    printf("  --index N           Test only device index N\n");
    printf("  --timeout-ms N      Read/write timeout in ms (default %u)\n", DEFAULT_TIMEOUT_MS);
    printf("  --io-len N          IO buffer length in bytes (default %u)\n", DEFAULT_IO_LEN);
    printf("  --stream            Enable FT_SetStreamPipe/FT_ClearStreamPipe\n");
    printf("  --stream-size N     Stream size (default %u)\n", DEFAULT_STREAM_SIZE);
    printf("  --set-params        Call FT_SetTransferParams for FIFO 0-3\n");
    printf("  --parallel          Open and test devices in parallel threads\n");
    printf("  --loops N           Repeat IO loop N times (default 1)\n");
    printf("  --seconds N         Run IO loop for N seconds (overrides --loops)\n");
    printf("  --errors-only       Only log non-FT_OK results\n");
    printf("  --channels N        Test FIFO 0..N-1 only (N=1,2,4)\n");
    printf("  --fifo-mask 0xF     Bitmask of FIFO IDs to test (bit0=FIFO0)\n");
    printf("  --help              Show this help\n");
}

static test_options parse_options(int argc, char **argv)
{
    test_options opts;
    memset(&opts, 0, sizeof(opts));
    opts.timeout_ms = DEFAULT_TIMEOUT_MS;
    opts.io_len = DEFAULT_IO_LEN;
    opts.stream_size = DEFAULT_STREAM_SIZE;
    opts.only_index = -1;
    opts.fifo_mask = 0x0F;
    opts.loops = 1;
    opts.seconds = 0;
    opts.errors_only = false;

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--index") == 0 && (i + 1) < argc) {
            unsigned long value = 0;
            if (!parse_ulong(argv[++i], &value)) {
                fprintf(stderr, "Invalid --index value\n");
                exit(1);
            }
            opts.only_index = (int)value;
        } else if (strcmp(argv[i], "--timeout-ms") == 0 && (i + 1) < argc) {
            unsigned long value = 0;
            if (!parse_ulong(argv[++i], &value)) {
                fprintf(stderr, "Invalid --timeout-ms value\n");
                exit(1);
            }
            opts.timeout_ms = (DWORD)value;
        } else if (strcmp(argv[i], "--io-len") == 0 && (i + 1) < argc) {
            unsigned long value = 0;
            if (!parse_ulong(argv[++i], &value)) {
                fprintf(stderr, "Invalid --io-len value\n");
                exit(1);
            }
            opts.io_len = (ULONG)value;
        } else if (strcmp(argv[i], "--stream") == 0) {
            opts.enable_stream = true;
        } else if (strcmp(argv[i], "--stream-size") == 0 && (i + 1) < argc) {
            unsigned long value = 0;
            if (!parse_ulong(argv[++i], &value)) {
                fprintf(stderr, "Invalid --stream-size value\n");
                exit(1);
            }
            opts.stream_size = (ULONG)value;
        } else if (strcmp(argv[i], "--set-params") == 0) {
            opts.enable_params = true;
        } else if (strcmp(argv[i], "--parallel") == 0) {
            opts.parallel = true;
        } else if (strcmp(argv[i], "--loops") == 0 && (i + 1) < argc) {
            unsigned long value = 0;
            if (!parse_ulong(argv[++i], &value) || value == 0) {
                fprintf(stderr, "Invalid --loops value\n");
                exit(1);
            }
            opts.loops = (int)value;
        } else if (strcmp(argv[i], "--seconds") == 0 && (i + 1) < argc) {
            unsigned long value = 0;
            if (!parse_ulong(argv[++i], &value) || value == 0) {
                fprintf(stderr, "Invalid --seconds value\n");
                exit(1);
            }
            opts.seconds = (int)value;
        } else if (strcmp(argv[i], "--errors-only") == 0) {
            opts.errors_only = true;
        } else if (strcmp(argv[i], "--channels") == 0 && (i + 1) < argc) {
            unsigned long value = 0;
            if (!parse_ulong(argv[++i], &value)) {
                fprintf(stderr, "Invalid --channels value\n");
                exit(1);
            }
            if (value == 1) {
                opts.fifo_mask = 0x01;
            } else if (value == 2) {
                opts.fifo_mask = 0x03;
            } else if (value == 4) {
                opts.fifo_mask = 0x0F;
            } else {
                fprintf(stderr, "--channels must be 1, 2, or 4\n");
                exit(1);
            }
        } else if (strcmp(argv[i], "--fifo-mask") == 0 && (i + 1) < argc) {
            unsigned long value = 0;
            if (!parse_ulong(argv[++i], &value)) {
                fprintf(stderr, "Invalid --fifo-mask value\n");
                exit(1);
            }
            opts.fifo_mask = (uint8_t)(value & 0x0F);
            if (opts.fifo_mask == 0) {
                fprintf(stderr, "--fifo-mask must select at least one FIFO\n");
                exit(1);
            }
        } else if (strcmp(argv[i], "--help") == 0) {
            print_usage(argv[0]);
            exit(0);
        } else {
            fprintf(stderr, "Unknown option: %s\n", argv[i]);
            print_usage(argv[0]);
            exit(1);
        }
    }

    return opts;
}

static void log_line(const test_options *opts, bool is_error, const char *fmt, ...)
{
    if (opts->errors_only && !is_error) {
        return;
    }

    va_list args;
    va_start(args, fmt);
    vprintf(fmt, args);
    va_end(args);
}

static pthread_mutex_t error_count_mutex = PTHREAD_MUTEX_INITIALIZER;
static int error_count = 0;

static void note_error(void)
{
    pthread_mutex_lock(&error_count_mutex);
    error_count++;
    pthread_mutex_unlock(&error_count_mutex);
}

static int get_error_count(void)
{
    int count = 0;
    pthread_mutex_lock(&error_count_mutex);
    count = error_count;
    pthread_mutex_unlock(&error_count_mutex);
    return count;
}

static void maybe_set_transfer_params(const test_options *opts)
{
    if (!opts->enable_params) {
        return;
    }

    FT_TRANSFER_CONF conf;
    memset(&conf, 0, sizeof(conf));
    conf.wStructSize = sizeof(conf);
    for (DWORD i = 0; i < 4; i++) {
        FT_STATUS status = FT_SetTransferParams(&conf, i);
        bool is_error = (status != FT_OK);
        if (is_error) {
            note_error();
        }
        log_line(opts, is_error, "[PARAMS] FIFO %u -> %s (%u)\n", i, ft_status_to_string(status), status);
    }
}

static void run_device_io(FT_HANDLE handle, int index, const test_options *opts)
{
    unsigned char *buffer = (unsigned char *)calloc(opts->io_len, sizeof(unsigned char));
    if (!buffer) {
        log_line(opts, true, "[DEV %d] Out of memory for IO buffer\n", index);
        note_error();
        return;
    }

    if (opts->enable_stream) {
        FT_STATUS status = FT_SetStreamPipe(handle, TRUE, TRUE, 0, opts->stream_size);
        bool is_error = (status != FT_OK);
        if (is_error) {
            note_error();
        }
        log_line(opts, is_error, "[DEV %d] FT_SetStreamPipe -> %s (%u)\n", index, ft_status_to_string(status), status);
    }

    int iterations = 0;
    time_t start_time = time(NULL);
    while (1) {
        for (int fifo = 0; fifo < 4; fifo++) {
            if ((opts->fifo_mask & (1u << fifo)) == 0) {
                continue;
            }
            DWORD transferred = 0;
            memset(buffer, 0xA5, opts->io_len);
            FT_STATUS status = FT_WritePipeEx(handle, (UCHAR)fifo, buffer, opts->io_len, &transferred, opts->timeout_ms);
            bool is_error = (status != FT_OK);
            if (is_error) {
                note_error();
            }
            log_line(opts, is_error, "[DEV %d] WRITE FIFO %d -> %s (%u), bytes=%lu\n",
                     index, fifo, ft_status_to_string(status), status, (unsigned long)transferred);

            transferred = 0;
            memset(buffer, 0, opts->io_len);
            status = FT_ReadPipeEx(handle, (UCHAR)fifo, buffer, opts->io_len, &transferred, opts->timeout_ms);
            is_error = (status != FT_OK);
            if (is_error) {
                note_error();
            }
            log_line(opts, is_error, "[DEV %d] READ  FIFO %d -> %s (%u), bytes=%lu\n",
                     index, fifo, ft_status_to_string(status), status, (unsigned long)transferred);
        }

        iterations++;
        if (opts->seconds > 0) {
            if (difftime(time(NULL), start_time) >= opts->seconds) {
                break;
            }
        } else {
            if (iterations >= opts->loops) {
                break;
            }
        }
    }

    if (opts->enable_stream) {
        FT_STATUS status = FT_ClearStreamPipe(handle, TRUE, TRUE, 0);
        bool is_error = (status != FT_OK);
        if (is_error) {
            note_error();
        }
        log_line(opts, is_error, "[DEV %d] FT_ClearStreamPipe -> %s (%u)\n", index, ft_status_to_string(status), status);
    }

    free(buffer);
}

typedef struct {
    int index;
    test_options opts;
} device_thread_args;

static pthread_mutex_t opened_count_mutex = PTHREAD_MUTEX_INITIALIZER;
static int opened_count = 0;

static void note_device_opened(void)
{
    pthread_mutex_lock(&opened_count_mutex);
    opened_count++;
    pthread_mutex_unlock(&opened_count_mutex);
}

static void *device_thread_main(void *arg)
{
    device_thread_args *ctx = (device_thread_args *)arg;
    int idx = ctx->index;
    const test_options *opts = &ctx->opts;

    FT_HANDLE handle = NULL;
    FT_STATUS status = FT_Create((PVOID)(uintptr_t)idx, FT_OPEN_BY_INDEX, &handle);
    if (status == FT_DEVICE_NOT_FOUND) {
        log_line(opts, true, "[OPEN] index %d -> %s (%u)\n", idx, ft_status_to_string(status), status);
        note_error();
        return NULL;
    }
    if (status != FT_OK || !handle) {
        log_line(opts, true, "[OPEN] index %d -> %s (%u)\n", idx, ft_status_to_string(status), status);
        note_error();
        return NULL;
    }

    log_line(opts, false, "[OPEN] index %d -> FT_OK (0)\n", idx);
    note_device_opened();
    run_device_io(handle, idx, opts);

    status = FT_Close(handle);
    if (status != FT_OK) {
        note_error();
    }
    log_line(opts, status != FT_OK, "[CLOSE] index %d -> %s (%u)\n", idx, ft_status_to_string(status), status);
    return NULL;
}

int main(int argc, char **argv)
{
    test_options opts = parse_options(argc, argv);
    error_count = 0;

    maybe_set_transfer_params(&opts);

    bool run_parallel = opts.parallel;
    DWORD device_count = 0;
    if (run_parallel && FT_OK != FT_CreateDeviceInfoList(&device_count)) {
        fprintf(stderr, "FT_CreateDeviceInfoList failed, falling back to sequential mode\n");
        run_parallel = false;
    }

    if (run_parallel) {
        int start = 0;
        int end = (int)device_count;

        if (opts.only_index >= 0) {
            start = opts.only_index;
            end = opts.only_index + 1;
        }

        if (end > MAX_TEST_DEVICES) {
            end = MAX_TEST_DEVICES;
        }

        int thread_count = end - start;
        if (thread_count <= 0) {
            printf("No devices opened.\n");
            return 0;
        }

        pthread_t *threads = (pthread_t *)calloc((size_t)thread_count, sizeof(pthread_t));
        device_thread_args *args = (device_thread_args *)calloc((size_t)thread_count, sizeof(device_thread_args));
        if (!threads || !args) {
            fprintf(stderr, "Out of memory for thread setup\n");
            free(threads);
            free(args);
            return 1;
        }

        opened_count = 0;
        for (int i = 0; i < thread_count; i++) {
            args[i].index = start + i;
            args[i].opts = opts;
            if (pthread_create(&threads[i], NULL, device_thread_main, &args[i]) != 0) {
                log_line(&opts, true, "Failed to create thread for index %d\n", args[i].index);
                note_error();
            }
        }

        for (int i = 0; i < thread_count; i++) {
            (void)pthread_join(threads[i], NULL);
        }

        free(threads);
        free(args);

        if (opened_count == 0) {
            log_line(&opts, true, "No devices opened.\n");
            note_error();
        }

        return get_error_count() > 0 ? 1 : 0;
    }

    int devices_tested = 0;
    for (int idx = 0; idx < MAX_TEST_DEVICES; idx++) {
        if (opts.only_index >= 0 && idx != opts.only_index) {
            continue;
        }

        FT_HANDLE handle = NULL;
        FT_STATUS status = FT_Create((PVOID)(uintptr_t)idx, FT_OPEN_BY_INDEX, &handle);
        if (status == FT_DEVICE_NOT_FOUND) {
            if (opts.only_index >= 0) {
                log_line(&opts, true, "[OPEN] index %d -> %s (%u)\n", idx, ft_status_to_string(status), status);
                note_error();
            }
            break;
        }
        if (status != FT_OK || !handle) {
            log_line(&opts, true, "[OPEN] index %d -> %s (%u)\n", idx, ft_status_to_string(status), status);
            note_error();
            continue;
        }

        log_line(&opts, false, "[OPEN] index %d -> FT_OK (0)\n", idx);
        run_device_io(handle, idx, &opts);

        status = FT_Close(handle);
        if (status != FT_OK) {
            note_error();
        }
        log_line(&opts, status != FT_OK, "[CLOSE] index %d -> %s (%u)\n", idx, ft_status_to_string(status), status);
        devices_tested++;
    }

    if (devices_tested == 0) {
        log_line(&opts, true, "No devices opened.\n");
        note_error();
    }

    return get_error_count() > 0 ? 1 : 0;
}

#include <thread>
#include <chrono>
#include "common.hpp"

static bool fifo_600mode;
static int run_seconds;
static thread measure_thread;
static thread write_thread;
static thread read_thread;
static const int BUFFER_LEN = 0x40000;
static const int QUEUE_LEN = 4;

static void write_test(FT_HANDLE handle) {
  FT_STATUS ftStatus;
  unique_ptr<unique_ptr<uint8_t[]>[]> buf(new unique_ptr<uint8_t[]>[QUEUE_LEN]);
  OVERLAPPED pOverlapped[QUEUE_LEN];
  uint8_t i = 0;
  uint8_t channel = 0;

  printf("write start\n");

  for (i = 0; i < QUEUE_LEN; i++) {
    ULONG count = 0;

    buf[i] = unique_ptr<uint8_t[]>(new uint8_t[BUFFER_LEN]);
    FT_InitializeOverlapped(handle, &pOverlapped[i]);

    ftStatus = FT_WritePipeAsync(handle, channel, buf[i].get(), BUFFER_LEN,
                                 &count, &pOverlapped[i]);

    if (ftStatus != FT_IO_PENDING && ftStatus != FT_OK) {
      printf("FT_WritePipeAsync ERROR =%d count=%u\n", ftStatus, count);
    }
  }

  i = 0;

  while (!do_exit) {
    ULONG count = 0;
    ftStatus = FT_GetOverlappedResult(handle, &pOverlapped[i], &count, TRUE);

    if (ftStatus != FT_OK) {
      printf("FT_GetOverlappedResult WRITE ERROR =%d count=%u\n", ftStatus,
             count);
      do_exit = true;
      break;
    }

    if (count == 0) {
      printf("WRITE zero-length packet, stopping\n");
      do_exit = true;
      break;
    }

    tx_count += count;

    FT_InitializeOverlapped(handle, &pOverlapped[i]);

    ftStatus = FT_WritePipeAsync(handle, channel, buf[i].get(), BUFFER_LEN,
                                 &count, &pOverlapped[i]);

    if (ftStatus != FT_IO_PENDING && ftStatus != FT_OK) {
      printf("FT_WritePipeAsync ERROR =%d count=%u\n", ftStatus, count);
    }

    if (++i == QUEUE_LEN)
      i = 0;
  }

  // Ensure any pending transfers are cancelled before releasing OVERLAPPEDs.
  (void)FT_AbortPipe(handle, 0x02);
  for (i = 0; i < QUEUE_LEN; i++) {
    ULONG count = 0;
    (void)FT_GetOverlappedResult(handle, &pOverlapped[i], &count, TRUE);
    FT_ReleaseOverlapped(handle, &pOverlapped[i]);
  }

  printf("write stopped\n");
}

static void read_test(FT_HANDLE handle) {
  FT_STATUS ftStatus;
  unique_ptr<unique_ptr<uint8_t[]>[]> buf(new unique_ptr<uint8_t[]>[QUEUE_LEN]);
  OVERLAPPED pOverlapped[QUEUE_LEN];
  uint8_t i = 0;
  uint8_t channel = 0;

  printf("Read start\n");

  for (i = 0; i < QUEUE_LEN; i++) {
    ULONG count = 0;

    buf[i] = unique_ptr<uint8_t[]>(new uint8_t[BUFFER_LEN]);
    FT_InitializeOverlapped(handle, &pOverlapped[i]);

    ftStatus = FT_ReadPipeAsync(handle, channel, buf[i].get(), BUFFER_LEN,
                                &count, &pOverlapped[i]);

    if (ftStatus != FT_IO_PENDING && ftStatus != FT_OK) {
      printf("FT_ReadPipeAsync ERROR =%d count=%u\n", ftStatus, count);
    }
  }

  i = 0;

  while (!do_exit) {
    ULONG count = 0;
    ftStatus = FT_GetOverlappedResult(handle, &pOverlapped[i], &count, TRUE);

    if (ftStatus != FT_OK) {
      printf("FT_GetOverlappedResult READ ERROR =%d count=%u\n", ftStatus,
             count);
      do_exit = true;
      break;
    }

    if (count == 0) {
      printf("READ zero-length packet -> stopping\n");
      do_exit = true;
      break;
    }

    rx_count += count;

    FT_InitializeOverlapped(handle, &pOverlapped[i]);

    ftStatus = FT_ReadPipeAsync(handle, channel, buf[i].get(), BUFFER_LEN,
                                &count, &pOverlapped[i]);

    if (ftStatus != FT_IO_PENDING && ftStatus != FT_OK) {
      printf("FT_ReadPipeAsync ERROR =%d count=%u\n", ftStatus, count);
    }

    if (++i == QUEUE_LEN)
      i = 0;
  }

  // Ensure any pending transfers are cancelled before releasing OVERLAPPEDs.
  (void)FT_AbortPipe(handle, 0x82);
  for (i = 0; i < QUEUE_LEN; i++) {
    ULONG count = 0;
    (void)FT_GetOverlappedResult(handle, &pOverlapped[i], &count, TRUE);
    FT_ReleaseOverlapped(handle, &pOverlapped[i]);
  }

  printf("Read stopped\n");
}

static void show_help(const char *bin) {
  printf("Usage: %s <out channels> <in channels> [mode] [seconds]\r\n", bin);
  printf("  out/in channels: [0, 1] for FT245 mode, [0-4] for FT600 mode\r\n");
  printf("  mode: 0 = FT245 (default), 1 = FT600\r\n");
  printf("  seconds: duration to run; 0 or omitted = run until Ctrl-C\r\n");
}

static bool validate_arguments(int argc, char *argv[]) {
  if (argc < 3 || argc > 5)
    return false;

  fifo_600mode = false;
  run_seconds = 0;

  out_ch_cnt = atoi(argv[1]);
  in_ch_cnt = atoi(argv[2]);

  if ((in_ch_cnt == 0 && out_ch_cnt == 0) || in_ch_cnt > 4 || out_ch_cnt > 4) {
    show_help(argv[0]);
    return false;
  }

  if (argc >= 4) {
    int val = atoi(argv[3]);
    if (val != 0 && val != 1)
      return false;
    fifo_600mode = (bool)val;
  }

  if (argc == 5) {
    run_seconds = atoi(argv[4]);
    if (run_seconds < 0)
      return false;
  }

  return true;
}

int main(int argc, char *argv[]) {

  get_version();

  if (!validate_arguments(argc, argv)) {
    show_help(argv[0]);
    return 1;
  }

  if (!get_device_lists(500))
    return 1;

  /* Must be called before FT_Create is called */
  turn_off_thread_safe();

  FT_HANDLE handle = NULL;

  FT_Create(0, FT_OPEN_BY_INDEX, &handle);
  if (!handle) {
    printf("Failed to create device\r\n");
    return -1;
  }

  // Async reads/writes default to a finite timeout in the library; disable
  // timeouts so the stream doesn't fail when no data is available yet.
  FT_SetPipeTimeout(handle, 0x82, 0); // IN pipe
  FT_SetPipeTimeout(handle, 0x02, 0); // OUT pipe

  FT_SetStreamPipe(handle, TRUE, TRUE, 0, BUFFER_LEN);
  
  if (out_ch_cnt)
    write_thread = thread(write_test, handle);
  if (in_ch_cnt)
    read_thread = thread(read_test, handle);
  measure_thread = thread(show_throughput, handle);
  register_signals();

  if (run_seconds > 0) {
    for (int i = 0; i < run_seconds && !do_exit; ++i)
      this_thread::sleep_for(chrono::seconds(1));
    do_exit = true;
  }
  if (write_thread.joinable())
    write_thread.join();
  if (read_thread.joinable())
    read_thread.join();
  if (measure_thread.joinable())
    measure_thread.join();

  FT_Close(handle);
  return 0;
}

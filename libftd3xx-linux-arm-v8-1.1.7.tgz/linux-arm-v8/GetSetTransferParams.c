/* get_transfer_params_test.c
 *
 * Test application for FT_GetTransferParams().
 *
 * Demonstrates reading back the active transfer parameters for all FIFO
 * channels.  Exercises three scenarios:
 *
 *   1. Before any FT_Create — library defaults should be returned.
 *   2. While a device is open — same values but the call is now permitted
 *      even with an open handle (unlike FT_SetTransferParams which is not).
 *   3. After calling FT_SetTransferParams with custom values and re-opening
 *      the device — the custom values should be reflected.
 *
 * Usage: ./get_transfer_params_test [--help]
 *
 * Build: included in the fifo_examples Makefile target list.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>

#ifdef _WIN32
#include "FTD3XX.h"
#else
#include "ftd3xx.h"
#endif

/* ------------------------------------------------------------------ */
static const char *ft_status_str(FT_STATUS s)
{
    switch (s) {
    case FT_OK:                  return "FT_OK";
    case FT_INVALID_HANDLE:      return "FT_INVALID_HANDLE";
    case FT_DEVICE_NOT_FOUND:    return "FT_DEVICE_NOT_FOUND";
    case FT_DEVICE_NOT_OPENED:   return "FT_DEVICE_NOT_OPENED";
    case FT_IO_ERROR:            return "FT_IO_ERROR";
    case FT_INSUFFICIENT_RESOURCES: return "FT_INSUFFICIENT_RESOURCES";
    case FT_INVALID_PARAMETER:   return "FT_INVALID_PARAMETER";
    case FT_TIMEOUT:             return "FT_TIMEOUT";
    case FT_OPERATION_ABORTED:   return "FT_OPERATION_ABORTED";
    case FT_BUSY:                return "FT_BUSY";
    case FT_OTHER_ERROR:         return "FT_OTHER_ERROR";
    default:                     return "UNKNOWN";
    }
}

/* Pretty-print an FT_TRANSFER_CONF for one FIFO channel */
static void print_conf(DWORD fifo_id, const FT_TRANSFER_CONF *c)
{
    printf("  FIFO %u:\n", (unsigned)fifo_id);
    printf("    IN  bURBCount=%u  wURBBufferCount=%u  dwURBBufferSize=%u  "
           "dwStreamingSize=%u  fPipeNotUsed=%d  fNonThreadSafe=%d\n",
           c->pipe[FT_PIPE_DIR_IN].bURBCount,
           c->pipe[FT_PIPE_DIR_IN].wURBBufferCount,
           (unsigned)c->pipe[FT_PIPE_DIR_IN].dwURBBufferSize,
           (unsigned)c->pipe[FT_PIPE_DIR_IN].dwStreamingSize,
           c->pipe[FT_PIPE_DIR_IN].fPipeNotUsed,
           c->pipe[FT_PIPE_DIR_IN].fNonThreadSafeTransfer);
    printf("    OUT bURBCount=%u  wURBBufferCount=%u  dwURBBufferSize=%u  "
           "dwStreamingSize=%u  fPipeNotUsed=%d  fNonThreadSafe=%d\n",
           c->pipe[FT_PIPE_DIR_OUT].bURBCount,
           c->pipe[FT_PIPE_DIR_OUT].wURBBufferCount,
           (unsigned)c->pipe[FT_PIPE_DIR_OUT].dwURBBufferSize,
           (unsigned)c->pipe[FT_PIPE_DIR_OUT].dwStreamingSize,
           c->pipe[FT_PIPE_DIR_OUT].fPipeNotUsed,
           c->pipe[FT_PIPE_DIR_OUT].fNonThreadSafeTransfer);
    printf("    fStopReadingOnURBUnderrun=%d  fBitBangMode=%d  "
           "fKeepDeviceSideBufferAfterReopen=%d\n",
           c->fStopReadingOnURBUnderrun,
           c->fBitBangMode,
           c->fKeepDeviceSideBufferAfterReopen);
}

/* Call FT_GetTransferParams for all 4 FIFO channels and print the result */
static void get_and_print_all(const char *label)
{
    printf("%s\n", label);
    for (DWORD i = 0; i < 4; i++) {
        FT_TRANSFER_CONF conf;
        memset(&conf, 0, sizeof(conf));
        conf.wStructSize = sizeof(conf);

        FT_STATUS status = FT_GetTransferParams(&conf, i);
        printf("  FT_GetTransferParams FIFO %u -> %s (%u)\n",
               (unsigned)i, ft_status_str(status), (unsigned)status);
        if (status == FT_OK)
            print_conf(i, &conf);
    }
    printf("\n");
}

/* ------------------------------------------------------------------ */
int main(int argc, char **argv)
{
    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--help") == 0) {
            printf("Usage: %s [--help]\n", argv[0]);
            printf("Tests FT_GetTransferParams() in three scenarios:\n");
            printf("  1. Before FT_Create (library defaults)\n");
            printf("  2. While device is open (read-only, always permitted)\n");
            printf("  3. After FT_SetTransferParams + re-open (custom values)\n");
            return 0;
        }
        fprintf(stderr, "Unknown option: %s\n", argv[i]);
        return 1;
    }

    /* ---- Step 1: read defaults before any FT_Create ---- */
    get_and_print_all("[STEP 1] FT_GetTransferParams before any FT_Create "
                      "(expect library defaults)");

    /* ---- Detect devices ---- */
    DWORD device_count = 0;
    FT_STATUS status = FT_CreateDeviceInfoList(&device_count);
    if (status != FT_OK) {
        printf("FT_CreateDeviceInfoList -> %s (%u)\n",
               ft_status_str(status), (unsigned)status);
        return 1;
    }
    printf("Detected %u device(s)\n\n", (unsigned)device_count);
    if (device_count == 0) {
        printf("No devices found — skipping open/close steps.\n");
        return 0;
    }

    /* ---- Step 2: open device, then read params (should still work) ---- */
    FT_HANDLE handle = NULL;
    status = FT_Create((PVOID)0, FT_OPEN_BY_INDEX, &handle);
    printf("[STEP 2] FT_Create index 0 -> %s (%u)\n\n",
           ft_status_str(status), (unsigned)status);

    if (status == FT_OK && handle) {
        get_and_print_all("[STEP 2a] FT_GetTransferParams while device is open "
                          "(should succeed and return same defaults)");

        status = FT_Close(handle);
        handle = NULL;
        printf("[STEP 2b] FT_Close -> %s (%u)\n\n",
               ft_status_str(status), (unsigned)status);
    }

    /* ---- Step 3: set custom params, re-open, then read back ---- */
    FT_TRANSFER_CONF custom;
    memset(&custom, 0, sizeof(custom));
    custom.wStructSize                           = sizeof(custom);
    custom.pipe[FT_PIPE_DIR_IN].bURBCount        = 16;
    custom.pipe[FT_PIPE_DIR_IN].wURBBufferCount  = 128;
    custom.pipe[FT_PIPE_DIR_IN].dwURBBufferSize  = 128 * 1024;
    custom.pipe[FT_PIPE_DIR_OUT].bURBCount       = 16;
    custom.pipe[FT_PIPE_DIR_OUT].wURBBufferCount = 128;
    custom.pipe[FT_PIPE_DIR_OUT].dwURBBufferSize = 128 * 1024;

    printf("[STEP 3] Applying custom FT_SetTransferParams "
           "(bURBCount=16, dwURBBufferSize=128K) for all FIFOs\n");
    for (DWORD i = 0; i < 4; i++) {
        status = FT_SetTransferParams(&custom, i);
        printf("  FT_SetTransferParams FIFO %u -> %s (%u)\n",
               (unsigned)i, ft_status_str(status), (unsigned)status);
    }
    printf("\n");

    get_and_print_all("[STEP 3a] FT_GetTransferParams before re-open "
                      "(custom values should be visible)");

    status = FT_Create((PVOID)0, FT_OPEN_BY_INDEX, &handle);
    printf("[STEP 3b] FT_Create index 0 -> %s (%u)\n\n",
           ft_status_str(status), (unsigned)status);

    if (status == FT_OK && handle) {
        get_and_print_all("[STEP 3c] FT_GetTransferParams while open with custom params");

        status = FT_Close(handle);
        handle = NULL;
        printf("[STEP 3d] FT_Close -> %s (%u)\n", ft_status_str(status), (unsigned)status);
    }

    return 0;
}

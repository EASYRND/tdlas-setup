#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef _WIN32
#include "FTD3XX.h"
#include <windows.h>
#else
#include "ftd3xx.h"
#include <unistd.h>
#endif

/* Set INFO=1 to query FT_CreateDeviceInfoList before FT_Create. */
#define INFO 0
/* Optional delay before FT_GetConfigurationDescriptor. */
#define WAIT_MS 0

static const char *status_string(FT_STATUS status)
{
    switch (status)
    {
    case FT_OK:
        return "FT_OK";
    case FT_INVALID_HANDLE:
        return "FT_INVALID_HANDLE";
    case FT_DEVICE_NOT_FOUND:
        return "FT_DEVICE_NOT_FOUND";
    case FT_DEVICE_NOT_OPENED:
        return "FT_DEVICE_NOT_OPENED";
    case FT_IO_ERROR:
        return "FT_IO_ERROR";
    case FT_INVALID_PARAMETER:
        return "FT_INVALID_PARAMETER";
    case FT_TIMEOUT:
        return "FT_TIMEOUT";
    case FT_BUSY:
        return "FT_BUSY";
    case FT_OTHER_ERROR:
        return "FT_OTHER_ERROR";
    default:
        return "FT_STATUS_UNKNOWN";
    }
}

static void print_configuration_descriptor(const FT_CONFIGURATION_DESCRIPTOR *config)
{
    printf("Configuration Descriptor:\n");
    printf("  bLength             : %u\n", (unsigned int)config->bLength);
    printf("  bDescriptorType     : 0x%02X\n", (unsigned int)config->bDescriptorType);
    printf("  wTotalLength        : %u\n", (unsigned int)config->wTotalLength);
    printf("  bNumInterfaces      : %u\n", (unsigned int)config->bNumInterfaces);
    printf("  bConfigurationValue : %u\n", (unsigned int)config->bConfigurationValue);
    printf("  iConfiguration      : %u\n", (unsigned int)config->iConfiguration);
    printf("  bmAttributes        : 0x%02X\n", (unsigned int)config->bmAttributes);
    printf("  MaxPower            : %u\n", (unsigned int)config->MaxPower);
}

int main(void)
{
    FT_STATUS status = FT_OK;
    FT_HANDLE handle = NULL;
    DWORD device_count = 0;
    FT_CONFIGURATION_DESCRIPTOR config;

    memset(&config, 0, sizeof(config));

    if (INFO)
    {
        printf("Calling FT_CreateDeviceInfoList...\n");
        status = FT_CreateDeviceInfoList(&device_count);
        if (status != FT_OK)
        {
            printf("ERROR: FT_CreateDeviceInfoList = %d (%s)\n",
                   (int)status,
                   status_string(status));
            return EXIT_FAILURE;
        }
        printf("Detected devices: %u\n", (unsigned int)device_count);
        if (device_count == 0)
        {
            printf("ERROR: no compatible devices detected.\n");
            return EXIT_FAILURE;
        }
    }

    status = FT_Create(0, FT_OPEN_BY_INDEX, &handle);
    if (status != FT_OK)
    {
        printf("ERROR: FT_Create = %d (%s)\n", (int)status, status_string(status));
        return EXIT_FAILURE;
    }

    if (WAIT_MS > 0)
    {
        printf("Waiting for %u ms before descriptor query...\n", (unsigned int)WAIT_MS);
#ifdef _WIN32
        Sleep(WAIT_MS);
#else
        /* POSIX path keeps this sample simple: second-level delay. */
        sleep((unsigned int)((WAIT_MS + 999u) / 1000u));
#endif
    }

    printf("Calling FT_GetConfigurationDescriptor...\n");
    status = FT_GetConfigurationDescriptor(handle, &config);
    if (status != FT_OK)
    {
        printf("ERROR: FT_GetConfigurationDescriptor = %d (%s)\n",
               (int)status,
               status_string(status));
        (void)FT_Close(handle);
        return EXIT_FAILURE;
    }

    print_configuration_descriptor(&config);

    status = FT_Close(handle);
    if (status != FT_OK)
    {
        printf("ERROR: FT_Close = %d (%s)\n", (int)status, status_string(status));
        return EXIT_FAILURE;
    }

    printf("Completed successfully.\n");
    return EXIT_SUCCESS;
}

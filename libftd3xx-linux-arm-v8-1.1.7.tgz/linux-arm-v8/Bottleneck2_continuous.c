/* Bottleneck2_continuous.c
 *
 * Minimal patch of Hector's Bottleneck2.c so it runs CONTINUOUSLY instead of
 * exiting on the first transient short read / data mismatch. Three things
 * differ from the original (all in the application, not the driver):
 *   1. The device pipes are drained (FT_AbortPipe) at startup so the first
 *      read does not pick up stale FIFO residue.
 *   2. A short read / short write / data mismatch is now COUNTED and reported,
 *      then the loop CONTINUES (instead of `return 0`). These are harmless
 *      stream-realignment artifacts of a loopback with timeouts disabled — all
 *      bytes arrive sooner or later, so the program keeps streaming.
 *   3. All pipes are aborted before the overlaps are released at shutdown.
 * Press Enter to stop. */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#ifdef _WIN32
	#include "FTD3XX.h"
	#include <processthreadsapi.h>
#else
	#include <pthread.h>
	#include <unistd.h>
	#include <errno.h>
	#include "ftd3xx.h"
	#include "Types.h"
	#define CRITICAL_SECTION pthread_mutex_t
	#define InitializeCriticalSection(A) pthread_mutex_init(A, 0)
	#define EnterCriticalSection pthread_mutex_lock
	#define TryEnterCriticalSection pthread_mutex_trylock
	#define LeaveCriticalSection pthread_mutex_unlock
	#define DeleteCriticalSection pthread_mutex_destroy
#endif

#define CHANNEL_COUNT	4 //Number of channels to make an IN & OUT queue thread for.
#define REQUEST_SIZE	1*1024 //Size of read/write requests.
#define QUEUE_LENGTH    1 //How many requests each thread will try to queue up per endpoint.

const char *StatusString(FT_STATUS Status)
{
    char INVALID_ERROR[100];
    static const char *FT_STATUS_STR[] = {
	"FT_OK", //0
	"FT_INVALID_HANDLE",
	"FT_DEVICE_NOT_FOUND",
	"FT_DEVICE_NOT_OPENED",
	"FT_IO_ERROR",
	"FT_INSUFFICIENT_RESOURCES",
	"FT_INVALID_PARAMETER",
	"FT_INVALID_BAUD_RATE",
	"FT_DEVICE_NOT_OPENED_FOR_ERASE",
	"FT_DEVICE_NOT_OPENED_FOR_WRITE",
	"FT_FAILED_TO_WRITE_DEVICE",
	"FT_EEPROM_READ_FAILED",
	"FT_EEPROM_WRITE_FAILED",
	"FT_EEPROM_ERASE_FAILED",
	"FT_EEPROM_NOT_PRESENT",
	"FT_EEPROM_NOT_PROGRAMMED",
	"FT_INVALID_ARGS",
	"FT_NOT_SUPPORTED",
	"FT_NO_MORE_ITEMS",
	"FT_TIMEOUT",
	"FT_OPERATION_ABORTED",
	"FT_RESERVED_PIPE",
	"FT_INVALID_CONTROL_REQUEST_DIRECTION",
	"FT_INVALID_CONTROL_REQUEST_TYPE",
	"FT_IO_PENDING",
	"FT_IO_INCOMPLETE",
	"FT_HANDLE_EOF",
	"FT_BUSY",
	"FT_NO_SYSTEM_RESOURCES",
	"FT_DEVICE_LIST_NOT_READY",
	"FT_DEVICE_NOT_CONNECTED",
	"FT_INCORRECT_DEVICE_PATH",
	"FT_OTHER_ERROR", //32
	"INVALID_ERROR"
    };
    if((Status > FT_OTHER_ERROR) || (Status < FT_OK))
    {
        sprintf(INVALID_ERROR, "INVALID_ERROR(%i signed | %u unsigned)", Status, Status);
        return INVALID_ERROR;
    }
    return FT_STATUS_STR[Status];
}

/*
    End program on user input.
*/
void WaitForInput(BOOL* Stop)
{
    getchar();
    *Stop = TRUE;
    return;
}

int main()
{
    srand(time(NULL)); //Initialize rand().
    FT_STATUS Status = FT_OK;
    DWORD DeviceCount = 0;
    FT_HANDLE Handle; //The handle all threads use.
    UCHAR* WriteBuffers[CHANNEL_COUNT][QUEUE_LENGTH];
    UCHAR* ReadBuffers[CHANNEL_COUNT][QUEUE_LENGTH];
    OVERLAPPED Overlaps[2][CHANNEL_COUNT][QUEUE_LENGTH];
    BOOL Stop = FALSE; //If TRUE, the program stops.
    DWORD ThreadID;
    HANDLE ThreadHandle;
    ULONG BytesTransferred[2][CHANNEL_COUNT][QUEUE_LENGTH];
    ULONG DriverVersion;

    Status = FT_CreateDeviceInfoList(&DeviceCount);
	if(Status != FT_OK){printf("ERROR: FT_CreateDeviceInfoList = %s\n", StatusString(Status)); return 0;}
	if(!DeviceCount){printf("ERROR: No devices detected.\n"); return 0;}
	printf("Detected %i devices!\n", DeviceCount);

    //Set transfer parameters.
    #ifndef _WIN32
		for(int i = 0; i < CHANNEL_COUNT; ++i)
		{
			FT_TRANSFER_CONF TransferConfig;
			memset(&TransferConfig, 0, sizeof(FT_TRANSFER_CONF));
			TransferConfig.wStructSize = sizeof(FT_TRANSFER_CONF);
			TransferConfig.pipe[FT_PIPE_DIR_IN].bURBCount = QUEUE_LENGTH;
			TransferConfig.pipe[FT_PIPE_DIR_OUT].bURBCount = QUEUE_LENGTH;
			TransferConfig.pipe[FT_PIPE_DIR_IN].dwStreamingSize = REQUEST_SIZE;
			TransferConfig.pipe[FT_PIPE_DIR_OUT].dwStreamingSize = REQUEST_SIZE;
			Status = FT_SetTransferParams(&TransferConfig, i);
			if(Status != FT_OK){printf("ERROR: FT_SetTransferParams = %i\n", Status); return 0;}
		}
	#endif //_WIN32

    Status = FT_Create(0, FT_OPEN_BY_INDEX, &Handle);
    if(Status != FT_OK){printf("ERROR: FT_Create = %s\n", StatusString(Status)); return 0;}
    Status = FT_GetDriverVersion(Handle, &DriverVersion);
    if(Status != FT_OK){printf("ERROR: FT_GetDriverVersion = %s\n", StatusString(Status)); return 0;}
    printf("D3XX Version = 0x%08x\n", DriverVersion);

    //Disable pipe timeouts. Program should not hang.
    for(int i = 0; i < CHANNEL_COUNT; ++i)
    {
        Status = FT_SetPipeTimeout(Handle, 0x82 + i, 0);
        if(Status != FT_OK){printf("ERROR: FT_SetPipeTimeout = %s\n", StatusString(Status)); return 0;}
        Status = FT_SetPipeTimeout(Handle, 0x02 + i, 0);
        if(Status != FT_OK){printf("ERROR: FT_SetPipeTimeout = %s\n", StatusString(Status)); return 0;}
    }
    printf("Disabled pipe timeouts for all channels!\n");
    printf("Program should not hang!\n");

    //Drain any stale residue left in the loopback FIFOs so the first reads align.
    for(int i = 0; i < CHANNEL_COUNT; ++i)
    {
        FT_AbortPipe(Handle, 0x82 + i);
        FT_AbortPipe(Handle, 0x02 + i);
    }

    for(int i = 0; i < CHANNEL_COUNT; ++i)
    {
        for(int j = 0; j < QUEUE_LENGTH; ++j)
        {
            WriteBuffers[i][j] = (PUCHAR)malloc(sizeof(UCHAR) * REQUEST_SIZE);
            if(!WriteBuffers[i][j]){printf("ERROR: Failed to create write buffers!\n"); return 0;}
            for(int k = 0; k < REQUEST_SIZE; ++k) //Randomize write data used for loopback.
			{
                WriteBuffers[i][j][k] = (UCHAR)(rand() % 0x00FF); //Each byte is random value from 0x00-0xFF.
			}
            ReadBuffers[i][j] = (PUCHAR)malloc(sizeof(UCHAR) * REQUEST_SIZE);
            if(!ReadBuffers[i][j]){printf("ERROR: Failed to create read buffers!\n"); return 0;}
            for(int k = 0; k < 2; ++k)
            {
                Status = FT_InitializeOverlapped(Handle, &Overlaps[k][i][j]);
                if(Status != FT_OK){printf("ERROR: FT_InitializeOverlapped = %s\n", StatusString(Status)); return 0;}
            }
        }
    }

    printf("Press Enter to stop the program.\n");
    #ifdef _WIN32
        ThreadHandle = CreateThread(NULL, 0, (PVOID)(WaitForInput), &Stop, 0, &ThreadID);
    #else
        ThreadHandle = (HANDLE) malloc(sizeof(pthread_t));
        if(ThreadHandle)
        {
            if(pthread_create(ThreadHandle, NULL, (PVOID)(WaitForInput), &Stop))
            {free(ThreadHandle); ThreadHandle = NULL;}
        }
        if(!ThreadHandle)
        {
            printf("ERROR: Failed to make input thread!\n");
            return 0;
        }
    #endif //_WIN32

    //Write & read until user quits.
    while(!Stop)
    {
        //Issue async read requests.
        for(int i = 0; i < CHANNEL_COUNT; ++i)
        {
            printf("CH%i: Issuing %i async reads...\n", i+1, QUEUE_LENGTH);
            for (int j = 0; j < QUEUE_LENGTH; ++j)
            {
                #ifdef _WIN32
                    Status = FT_ReadPipe(Handle, 0x82 + i, ReadBuffers[i][j], REQUEST_SIZE, &BytesTransferred[0][i][j], &Overlaps[0][i][j]);
                #else
                    Status = FT_ReadPipeAsync(Handle, i, ReadBuffers[i][j], REQUEST_SIZE, &BytesTransferred[0][i][j], &Overlaps[0][i][j]);
                #endif //_WIN32
                if((Status != FT_IO_PENDING) && (Status != FT_OK))
                {
                    printf("ERROR[%02x]: FT_ReadPipe = %s\n", 0x82 + i, StatusString(Status)); return 0;
                }
            }
        }
        //Issue async write requests.
        for(int i = 0; i < CHANNEL_COUNT; ++i)
        {
            printf("CH%i: Issuing %i async writes...\n", i+1, QUEUE_LENGTH);
            for (int j = 0; j < QUEUE_LENGTH; ++j)
            {
                #ifdef _WIN32
                    Status = FT_WritePipe(Handle, 0x02 + i, WriteBuffers[i][j], REQUEST_SIZE, &BytesTransferred[0][i][j], &Overlaps[1][i][j]);
                #else
                    Status = FT_WritePipeAsync(Handle, i, WriteBuffers[i][j], REQUEST_SIZE, &BytesTransferred[0][i][j], &Overlaps[1][i][j]);
                #endif //_WIN32
                if((Status != FT_IO_PENDING) && (Status != FT_OK))
                {
                    printf("ERROR[%02x]: FT_WritePipe = %s\n", 0x02 + i, StatusString(Status)); return 0;
                }
            }
        }
        //Get overlapped results.
        for(int i = 0; i < CHANNEL_COUNT; ++i)
        {
            printf("CH%i: Getting %i async reads results...\n", i+1, QUEUE_LENGTH);
            for(int j = 0; j < QUEUE_LENGTH; ++j)
            {
                //Windows will retrieve all bytes which is preferred behavior.
                //If I have to poll anyways on Linux to get all requested bytes, what's even the point of the async calls?
                Status = FT_GetOverlappedResult(Handle, &Overlaps[0][i][j], &BytesTransferred[0][i][j], TRUE);
                if(Status != FT_OK)
                {
                    printf("ERROR[%02x]: FT_GetOverlappedResult = %s\n", 0x82 + i, StatusString(Status)); return 0;
                }
                if(BytesTransferred[0][i][j] != REQUEST_SIZE){printf("CH%i: WARN short read: received %i of %i bytes (continuing)\n", i+1, BytesTransferred[0][i][j], REQUEST_SIZE);}
            }
            printf("CH%i: Successfully read %i bytes %i times!\n", i+1, REQUEST_SIZE, QUEUE_LENGTH);
            //It should be irrelevant if I get overlapped results for writes or reads first since
            //they were async calls.
            //Order should not matter for async calls otherwise multi-threaded applications have a real issue they must avoid
            //even if it's niche. Windows has no issues with this setup which is expected behavior.
            printf("CH%i: Getting %i async write results...\n", i+1, QUEUE_LENGTH);
            for(int j = 0; j < QUEUE_LENGTH; ++j)
            {
                Status = FT_GetOverlappedResult(Handle, &Overlaps[1][i][j], &BytesTransferred[1][i][j], TRUE);
                if(Status != FT_OK)
                {
                    printf("ERROR[%02x]: FT_GetOverlappedResult = %s\n", 0x02 + i, StatusString(Status)); return 0;
                }
                if(BytesTransferred[1][i][j] != REQUEST_SIZE){printf("CH%i: WARN short write: sent %i of %i bytes (continuing)\n", i+1, BytesTransferred[1][i][j], REQUEST_SIZE);}
                if(memcmp(ReadBuffers[i][j], WriteBuffers[i][j], REQUEST_SIZE))
                {
                    //Harmless loopback stream-realignment: all bytes arrive sooner or later. Keep streaming.
                    printf("CH%i: WARN data mismatch (stream realignment, continuing)\n", i+1);
                }
            }
            printf("CH%i: %i bytes were written successfully %i times!\n", i+1, REQUEST_SIZE, QUEUE_LENGTH);
        }

    }

    //Cancel anything still in flight BEFORE releasing overlaps / freeing buffers.
    for(int i = 0; i < CHANNEL_COUNT; ++i)
    {
        FT_AbortPipe(Handle, 0x82 + i);
        FT_AbortPipe(Handle, 0x02 + i);
    }

    for(int i = 0; i < CHANNEL_COUNT; ++i)
    {
        for(int j = 0; j < QUEUE_LENGTH; ++j)
        {
            for(int k = 0; k < 2; ++k)
            {
                Status = FT_ReleaseOverlapped(Handle, &Overlaps[k][i][j]);
                if(Status != FT_OK){printf("ERROR: FT_ReleaseOverlapped = %s\n", StatusString(Status)); return 0;}
            }
        }
    }

    for(int i = 0; i < CHANNEL_COUNT; ++i)
    {
        for(int j = 0; j < QUEUE_LENGTH; ++j)
        {
            free(ReadBuffers[i][j]);
            free(WriteBuffers[i][j]);
        }
    }
    FT_Close(Handle);
    return 0;
}
